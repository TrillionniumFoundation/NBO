"""Original-law derivative certificates and representation-neutral scalar repair."""
from __future__ import annotations
import math
import numpy as np
from interval100 import I
from economy100 import BETA,DELTA

def gamma_interval(a,A,d,mu=2.):
    """Outward upper regret from one true subgradient in interval d.
    For scalar actions the worst supporting gap is at an interval endpoint.
    All minimization candidates are exact algebraic projections with outward arithmetic.
    The normal residual bound is a conservative check, not the implementation formula.
    """
    vals=[]
    for s in (float(d.lo),float(d.hi)):
        # Closed form of maximum of -s*t-mu*t^2/2 over [-a,A-a].
        if s>mu*a: v=I(s)*a-I(mu/2)*I(a).sq()
        elif s< -mu*float((I(A)-a).hi):v=-I(s)*(I(A)-a)-I(mu/2)*(I(A)-a).sq()
        else:v=I(s).sq()/(2*mu)
        vals.append(float(v.hi))
    return max(0.,*vals)

class Certifier:
    def __init__(self,economy):self.e=economy
    def successors(self,x,a,z):
        return self.e.transition((I(x[0]),I(x[1])),I(a),z)
    def tail(self,x,a,steps=32):
        """Bracket an optimal excluded-interval left endpoint for original V1."""
        alpha=self.e.alpha;length=2*DELTA*alpha
        lo=-DELTA;hi=DELTA-length
        def difference(z):
            zz=I(np.array([z,z+length]));xx=self.successors(x,a,zz)
            values=self.e.vpoint(xx);self.e.counts.tail_value_queries+=2
            return values[1]-values[0]
        d=difference(lo)
        if float(d.lo)>=0:return lo,lo
        d=difference(hi)
        if float(d.hi)<=0:return hi,hi
        for _ in range(steps):
            m=(lo+hi)/2;d=difference(m)
            if float(d.hi)<0:lo=m
            elif float(d.lo)>0:hi=m
            else:break
        return lo,hi
    def marginal(self,x,a,n,tail=None):
        if tail is None:tail=self.tail(x,a)
        lo,hi=tail;m=(lo+hi)/2;length=2*DELTA*self.e.alpha
        # Exactly representable endpoints are enclosed during mesh construction.
        total=I(0)
        for l,r in ((-DELTA,m),(m+length,DELTA)):
            if r<=l:continue
            idx=I(np.arange(n+1,dtype=float))/n
            edges=I(l)+(I(r)-l)*idx
            boxes=I(edges.lo[:-1],edges.hi[1:]);xx=self.successors(x,a,boxes)
            _,grad,_=self.e.value_grad(xx,box=True,steps=30)
            gg=grad[0]/2+grad[1]/4
            total+=((I(r)-l)/n*gg).sum()
            self.e.counts.marginal_cells+=n
        deriv=2*I(a)+16*I(a).sq()*a+BETA*total/(2*DELTA*(1-self.e.alpha))
        # |partial_a V1(F)| <= (15/2)*(1/2+1/4) = 45/8.
        # Reallocating equal tail masses gives oscillation <=45/4.
        err=I(BETA)*(45/4)*((I(hi)-lo)/2)/(2*DELTA*(1-self.e.alpha))
        return deriv+I(-err.hi,err.hi),tail
    def objective(self,x,a,n=128,tail=None):
        if tail is None:tail=self.tail(x,a)
        lo,hi=tail;m=(lo+hi)/2;length=2*DELTA*self.e.alpha
        lower=I(0);upper=I(0)
        for l,r in ((-DELTA,m),(m+length,DELTA)):
            if r<=l:continue
            edge=I(l)+(I(r)-l)*(I(np.arange(n+1,dtype=float))/n)
            mids=(edge[:-1]+edge[1:])/2
            v=self.e.vpoint(self.successors(x,a,mids))
            w=self.e.vpoint(self.successors(x,a,edge))
            lower+=((I(r)-l)/n*v).sum()
            upper+=((I(r)-l)/n*(w[:-1]+w[1:])/2).sum()
            self.e.counts.value_nodes+=3*n+1
        # V1 is 15/2-Lipschitz per coordinate; z range length=1/16.
        tailerror=(I(15)*(I(hi)-lo)/2)/(1-self.e.alpha)
        qbase=self.e.stage((I(x[0]),I(x[1])))+I(a).sq()+4*I(a).sq().sq()
        L=qbase+BETA*lower/(2*DELTA*(1-self.e.alpha))
        U=qbase+BETA*(upper/(2*DELTA*(1-self.e.alpha))+tailerror)
        return I(float(L.lo),float(U.hi)),tail
    def solve(self,x,proposal,tau,max_n=4096,max_actions=64):
        A=1/8+(x[0]+x[1])/16
        if not 0<=proposal<=A:raise ValueError('infeasible proposal')
        budget=tau-BETA*2**-20
        if budget<=0:raise ValueError('terminal allowance consumes tolerance')
        lo=0.;hi=A;a=float(proposal);attempts=[];accepted=False
        for step in range(max_actions):
            n=4;tail=self.tail(x,a)
            while True:
                d,_=self.marginal(x,a,n,tail);g=gamma_interval(a,A,d)
                if g<=budget:
                    accepted=True;break
                if float(d.lo)>0 or float(d.hi)<0:break
                if n>=max_n:break
                n*=2
            attempts.append({'action':a,'n':n,'gradient':d.pair(),'gamma':g,'tail':list(tail)})
            if accepted:break
            if float(d.lo)>0:hi=a
            elif float(d.hi)<0:lo=a
            else:break
            new=(lo+hi)/2
            if new==a:break
            a=new
        return {'qualified':accepted,'proposal':float(proposal),'action':a,'first_rejected':len(attempts)>1 or not accepted,
                'attempts':attempts,'regret_upper':float((I(g)+BETA*2**-20).hi),
                'action_distance_upper':math.nextafter(math.sqrt(max(0,g)),math.inf), 'action_bracket':[lo,hi]}
