"""Outward binary64 interval arithmetic; finite IEEE-754 inputs only.
Every basic arithmetic operation is enlarged by nextafter. No transcendental
function is used by the original-model certification path.
"""
from __future__ import annotations
import numpy as np

class I:
    __slots__ = ('lo','hi')
    __array_priority__ = 1000
    def __init__(self, lo, hi=None):
        if isinstance(lo,I): self.lo,self.hi=lo.lo,lo.hi; return
        self.lo=np.asarray(lo,dtype=float)
        self.hi=np.asarray(lo if hi is None else hi,dtype=float)
        if np.any(self.lo>self.hi) or np.any(~np.isfinite(self.lo)) or np.any(~np.isfinite(self.hi)):
            raise ValueError('invalid/nonfinite interval')
    @staticmethod
    def down(a): return np.nextafter(a,-np.inf)
    @staticmethod
    def up(a): return np.nextafter(a,np.inf)
    def __add__(self,b):
        b=I(b);return I(self.down(self.lo+b.lo),self.up(self.hi+b.hi))
    __radd__=__add__
    def __neg__(self):return I(-self.hi,-self.lo)
    def __sub__(self,b):return self+-I(b)
    def __rsub__(self,b):return I(b)+-self
    def __mul__(self,b):
        b=I(b);p=[self.lo*b.lo,self.lo*b.hi,self.hi*b.lo,self.hi*b.hi]
        return I(self.down(np.minimum.reduce(p)),self.up(np.maximum.reduce(p)))
    __rmul__=__mul__
    def __truediv__(self,b):
        b=I(b)
        if np.any((b.lo<=0)&(b.hi>=0)):raise ZeroDivisionError('interval crosses zero')
        return self*I(self.down(1/b.hi),self.up(1/b.lo))
    def __rtruediv__(self,b):return I(b)/self
    def sq(self):
        l=np.minimum(self.lo*self.lo,self.hi*self.hi)
        l=np.where((self.lo<=0)&(self.hi>=0),0,l)
        return I(np.maximum(0,self.down(l)),self.up(np.maximum(self.lo*self.lo,self.hi*self.hi)))
    def pos(self):return I(np.maximum(0,self.lo),np.maximum(0,self.hi))
    def clip(self,lo,hi):return I(np.clip(self.lo,lo,hi),np.clip(self.hi,lo,hi))
    def sum(self):
        # Pairwise reduction: all reduction additions are outward, not a single ULP padding.
        l=self.lo.ravel().copy();h=self.hi.ravel().copy()
        if not len(l):return I(0)
        while len(l)>1:
            n=len(l)//2;ll=self.down(l[:2*n:2]+l[1:2*n:2]);hh=self.up(h[:2*n:2]+h[1:2*n:2])
            if len(l)%2:ll=np.append(ll,l[-1]);hh=np.append(hh,h[-1])
            l,h=ll,hh
        return I(l[0],h[0])
    def mid(self):return self.lo+(self.hi-self.lo)/2
    def pair(self):return [float(self.lo),float(self.hi)]
    def __getitem__(self,k):return I(self.lo[k],self.hi[k])
    def __repr__(self):return f'I({self.lo!r},{self.hi!r})'
