from __future__ import annotations
import unittest,math,json,time
from fractions import Fraction as F
import numpy as np
from interval100 import I
from economy100 import Economy
from certificate100 import Certifier,gamma_interval
from independent100 import q_terminal,derivative_terminal,scalar_gap_exact

class TestInterval(unittest.TestCase):
    def test_rational_operations(self):
        for a in [F(1,3),F(-7,11),F(17,32),F(0)]:
            for b in [F(3,7),F(-2,9),F(1,64)]:
                aa=I(math.nextafter(float(a),-math.inf),math.nextafter(float(a),math.inf));bb=I(math.nextafter(float(b),-math.inf),math.nextafter(float(b),math.inf))
                for v,exact in [(aa+bb,a+b),(aa-bb,a-b),(aa*bb,a*b),(aa/bb,a/b)]:
                    self.assertLessEqual(F(float(v.lo)),exact);self.assertGreaterEqual(F(float(v.hi)),exact)
    def test_sum_outward(self):
        x=np.array([.1,-1e12,.3,1e12,.2]);v=I(x).sum();s=sum(map(F,x))
        self.assertLessEqual(F(float(v.lo)),s);self.assertGreaterEqual(F(float(v.hi)),s)
    def test_invalid(self):
        with self.assertRaises(ValueError):I(2,1)
        with self.assertRaises(ZeroDivisionError):I(1)/I(-1,1)

class TestEconomy(unittest.TestCase):
    def test_exact_rational_avars(self):
        for alpha in (.5,.75):
            e=Economy(alpha)
            for x in [(F(1,5),F(7,10)),(F(2,5),F(3,5)),(F(1,2),F(1,2)),(F(7,8),F(3,8))]:
                # Exact binary input rationals, not implicit decimal exactness.
                xf=tuple(float(v) for v in x);xx=tuple(F(v) for v in xf)
                for a in (0.,1/32,3/32):
                    q,d=e.terminal(tuple(I(v) for v in xf),I(a));exact=q_terminal(xx,F(a),F(alpha))
                    self.assertLessEqual(F(float(q.lo)),exact);self.assertGreaterEqual(F(float(q.hi)),exact)
                    sd=derivative_terminal(xx,F(a),F(alpha))
                    self.assertLessEqual(float(d.lo)-1e-12,float(sd));self.assertGreaterEqual(float(d.hi)+1e-12,float(sd))
    def test_optimal_boxes_include_points(self):
        for alpha in (.5,.75):
            e=Economy(alpha)
            for center in [(.2,.7),(.55,.55),(.7,.3),(.85,.85)]:
                boxes=(I(center[0]-.015,center[0]+.015),I(center[1]-.015,center[1]+.015))
                qb,gb,ub=e.value_grad(boxes,True)
                for x in [(center[0]+dx,center[1]+dy) for dx in [-.015,0,.015] for dy in [-.015,0,.015]]:
                    q,g,a=e.fast_value_grad(np.array(x));A=1/8+sum(x)/16
                    self.assertLessEqual(float(ub.lo)-1e-10,float(a/A));self.assertGreaterEqual(float(ub.hi)+1e-10,float(a/A))
                    self.assertLessEqual(float(qb.lo)-1e-10,float(q));self.assertGreaterEqual(float(qb.hi)+1e-10,float(q))
                    for j in (0,1):self.assertLessEqual(float(gb[j].lo)-1e-10,g[j]);self.assertGreaterEqual(float(gb[j].hi)+1e-10,g[j])
    def test_envelope_gradient(self):
        e=Economy(.75);h=2**-18
        for x in [np.array([.2,.7]),np.array([.55,.55]),np.array([.7,.3]),np.array([.85,.85])]:
            q,g,a=e.fast_value_grad(x)
            for j in (0,1):
                dx=np.eye(2)[j]*h
                fd=(e.fast_value_grad(x+dx)[0]-e.fast_value_grad(x-dx)[0])/(2*h)
                self.assertAlmostEqual(float(fd),float(g[j]),places=7)
    def test_terminal_policy(self):
        for alpha in (.5,.75):
            e=Economy(alpha)
            for x in [(.2,.7),(.55,.55),(.85,.85)]:
                a,g=e.terminal_policy(x);self.assertTrue(0<=a<=1/8+sum(x)/16);self.assertLess(g,2**-20)

class TestCertificate(unittest.TestCase):
    def test_exact_gap_and_boundaries(self):
        for a in [0.,1/64,1/8,1/4]:
            for s in [-3.,-.4,0.,.1,4.]:
                g=gamma_interval(a,.25,I(s));exact=scalar_gap_exact(a,.25,s)
                self.assertGreaterEqual(F(g),exact)
                self.assertLess(g-float(exact),1e-13)
    def test_derivative_contains_finite_difference(self):
        for alpha in (.5,.75):
            e=Economy(alpha);c=Certifier(e);x=(.55,.45);a=.08;h=2**-12
            d,tail=c.marginal(x,a,32)
            left,_=c.objective(x,a-h,256);right,_=c.objective(x,a+h,256)
            # Numerical diagnostic, separate from exact tests and mathematical proof.
            fd=(float(right.mid())-float(left.mid()))/(2*h)
            self.assertTrue(float(d.lo)-1e-5<=fd<=float(d.hi)+1e-5)
    def test_original_objective_containment(self):
        e=Economy(.5);c=Certifier(e);x=(.55,.45);a=.08
        coarse,_=c.objective(x,a,8);fine,_=c.objective(x,a,128)
        self.assertLessEqual(float(coarse.lo),float(fine.lo));self.assertGreaterEqual(float(coarse.hi),float(fine.hi))
    def test_certified_repair(self):
        for alpha in (.5,.75):
            e=Economy(alpha);c=Certifier(e);x=(.55,.45)
            out=c.solve(x,0,2**-10)
            self.assertTrue(out['qualified']);self.assertLessEqual(out['regret_upper'],2**-10)
            self.assertGreater(len(out['attempts']),1)
    def test_mutated_gradient_rejected(self):
        e=Economy(.5);c=Certifier(e);d,_=c.marginal((.2,.7),0,16)
        # False zero gradient would certify the boundary, whereas real derivative cannot.
        self.assertGreater(gamma_interval(0,.18125,d),2**-8)
        self.assertLessEqual(gamma_interval(0,.18125,I(0)),1e-300)

if __name__=='__main__':unittest.main(verbosity=2)
