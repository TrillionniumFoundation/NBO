"""Unchanged R95/R99 investment economy; independent semianalytic terminal oracle.
All certifying arithmetic uses interval100.I. Plain NumPy methods are proposal /
training conveniences and are never accepted as certificates on their own.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
import numpy as np
from interval100 import I
BETA=15/16
DELTA=1/32
@dataclass
class Counts:
    terminal_point_evaluations:int=0
    terminal_box_evaluations:int=0
    terminal_solves:int=0
    tail_value_queries:int=0
    marginal_cells:int=0
    value_nodes:int=0
    proposal_calls:int=0
    def json(self):return asdict(self)
    def work(self):return self.terminal_point_evaluations+self.terminal_box_evaluations

class Economy:
    def __init__(self,alpha):
        if alpha not in (.5,.75):raise ValueError('fixed original-model risk levels only')
        self.alpha=alpha;self.counts=Counts()
    @staticmethod
    def capacity(x):return 1/8+(x[0]+x[1])/16
    @staticmethod
    def stage(x):
        x1,x2=x
        return (x1-5/8).sq()+(x2-5/8).sq()+(x1-x2).sq()/4+2*(.5-x1-x2).pos().sq()
    @staticmethod
    def stage_grad(x):
        x1,x2=x;v=-4*(.5-x1-x2).pos()
        return 2*(x1-5/8)+(x1-x2)/2+v,2*(x2-5/8)-(x1-x2)/2+v
    @staticmethod
    def transition(x,a,z):
        x1,x2=x
        return (1/16+x1/2+x2/8+x1*(1-x2)/16+a/2+z,
                1/16+x2/2+x1/8+x2*(1-x1)/16+a/4-z)
    def terminal(self,x,a,box=False,with_state=False):
        """Q1 and Q1 action derivative at arbitrary feasible or nearby a.
        The exact convex quadratic-in-z AVaR removes an alpha-mass interval
        centered at clipped vertex -(y1-y2)/2. Integrals are polynomial.
        """
        size=np.broadcast_shapes(x[0].lo.shape,x[1].lo.shape,a.lo.shape)
        n=int(np.prod(size)) if size else 1
        if box:self.counts.terminal_box_evaluations+=n
        else:self.counts.terminal_point_evaluations+=n
        y1,y2=self.transition(x,a,I(0));D=y1-y2;H=(.5-y1-y2).pos()
        center=(-D/2).clip(-DELTA*(1-self.alpha),DELTA*(1-self.alpha))
        ez=-self.alpha*center/(1-self.alpha)
        ez2=(I(DELTA).sq()/3-self.alpha*(center.sq()+I(self.alpha*DELTA).sq()/3))/(1-self.alpha)
        constant=2*((y1-5/8).sq()+(y2-5/8).sq())+D.sq()/4+2*H.sq()
        risk=constant+5*D*ez+5*ez2
        h=a.sq()+4*a.sq().sq();hp=2*a+16*a.sq()*a
        q=self.stage(x)+h+BETA*risk
        g1=4*(y1-5/8)+D/2-4*H+5*ez
        g2=4*(y2-5/8)-D/2-4*H-5*ez
        qa=hp+BETA*(g1/2+g2/4)
        if not with_state:return q,qa
        x1,x2=x;s1,s2=self.stage_grad(x)
        gx1=s1+BETA*(g1*(.5+(1-x2)/16)+g2*(1/8-x2/16))
        gx2=s2+BETA*(g1*(1/8-x1/16)+g2*(.5+(1-x1)/16))
        return q,qa,(gx1,gx2)
    def optimal_u_box(self,x,steps=44,box=False):
        A=self.capacity(x);shape=np.broadcast_shapes(A.lo.shape,A.hi.shape)
        lo=np.zeros(shape);hi=np.ones(shape)
        q0,d0=self.terminal(x,I(0)*A,box=box)
        q1,d1=self.terminal(x,A,box=box)
        hi=np.where(d0.lo>=0,0,hi);lo=np.where(d1.hi<=0,1,lo)
        # Boundary alternatives cannot conflict because Q1 is strongly convex and A>0.
        for _ in range(steps):
            mid=lo+(hi-lo)/2
            if np.all(hi-lo<2**-42):break
            _,d=self.terminal(x,I(mid)*A,box=box)
            up=d.lo>0;dn=d.hi<0
            nlo=np.where(dn,mid,lo);nhi=np.where(up,mid,hi)
            # For uncertain signs, monotonicity with derivative in u >=2*A_min.
            # Residual localization also covers constrained boundary minimizers.
            slope=2*float(np.min(A.lo))
            localized=I(mid)-I(np.minimum(d.lo,0),np.maximum(d.hi,0))/I(slope)
            nlo=np.maximum(nlo,np.maximum(0,localized.lo))
            nhi=np.minimum(nhi,np.minimum(1,localized.hi))
            if np.any(nlo>nhi):raise ArithmeticError('optimizer interval contradiction')
            if np.all((nlo==lo)&(nhi==hi)):break
            lo,hi=nlo,nhi
        self.counts.terminal_solves+=int(np.prod(shape)) if shape else 1
        return I(lo,hi)
    def value_grad(self,x,box=False,steps=44):
        u=self.optimal_u_box(x,steps,box);A=self.capacity(x)
        q,qa,gx=self.terminal(x,u*A,box=box,with_state=True)
        # Envelope theorem in normalized coordinate u: valid at both action boundaries.
        v1=gx[0]+qa*u/16;v2=gx[1]+qa*u/16
        return q,(v1,v2),u
    def vpoint(self,x):return self.value_grad(x)[0]
    def terminal_policy(self,x):
        """40-bit downward observation; verify terminal regret before returning action."""
        observed=tuple(I(np.floor(np.asarray(v)*2**40)/2**40) for v in x)
        _,_,u=self.value_grad(observed)
        A=self.capacity(observed);a=np.minimum(u.mid()*A.mid(),A.lo)
        _,d=self.terminal(observed,I(a))
        from certificate100 import gamma_interval
        cert=gamma_interval(float(a),float(A.hi),d)
        if cert>2**-24:raise ArithmeticError('terminal controller failed qualification')
        return float(a),cert+30*2**-40

    # Noncertifying high-accuracy floating oracle for proposal generation and labels.
    def fast_terminal(self,x,a,grad=False):
        x=np.asarray(x);x1,x2=x[...,0],x[...,1];a=np.asarray(a)
        self.counts.terminal_point_evaluations+=int(np.broadcast_arrays(x1,a)[0].size)
        y1=1/16+x1/2+x2/8+x1*(1-x2)/16+a/2
        y2=1/16+x2/2+x1/8+x2*(1-x1)/16+a/4
        D=y1-y2;H=np.maximum(0,.5-y1-y2)
        m=np.clip(-D/2,-DELTA*(1-self.alpha),DELTA*(1-self.alpha))
        ez=-self.alpha*m/(1-self.alpha)
        ez2=(DELTA**2/3-self.alpha*(m*m+(self.alpha*DELTA)**2/3))/(1-self.alpha)
        S=(x1-5/8)**2+(x2-5/8)**2+(x1-x2)**2/4+2*np.maximum(0,.5-x1-x2)**2
        C=2*((y1-5/8)**2+(y2-5/8)**2)+D*D/4+2*H*H
        q=S+a*a+4*a**4+BETA*(C+5*D*ez+5*ez2)
        g1=4*(y1-5/8)+D/2-4*H+5*ez;g2=4*(y2-5/8)-D/2-4*H-5*ez
        qa=2*a+16*a**3+BETA*(g1/2+g2/4)
        if not grad:return q,qa
        sg=-4*np.maximum(0,.5-x1-x2)
        gx1=2*(x1-5/8)+(x1-x2)/2+sg+BETA*(g1*(.5+(1-x2)/16)+g2*(1/8-x2/16))
        gx2=2*(x2-5/8)-(x1-x2)/2+sg+BETA*(g1*(1/8-x1/16)+g2*(.5+(1-x1)/16))
        return q,qa,np.stack((gx1,gx2),axis=-1)
    def fast_value_grad(self,x):
        x=np.asarray(x);A=1/8+x.sum(axis=-1)/16;lo=np.zeros_like(A);hi=A.copy()
        for _ in range(44):
            a=(lo+hi)/2;_,d=self.fast_terminal(x,a)
            lo=np.where(d<0,a,lo);hi=np.where(d>=0,a,hi)
        a=(lo+hi)/2
        _,dl=self.fast_terminal(x,np.zeros_like(a));_,du=self.fast_terminal(x,A)
        a=np.where(dl>=0,0,np.where(du<=0,A,a))
        q,qa,g=self.fast_terminal(x,a,True)
        u=a/A;g=g+qa[...,None]*u[...,None]/16
        return q,g,a
    @staticmethod
    def fast_transition(x,a,z):
        x=np.asarray(x);x1,x2=x[...,0],x[...,1]
        return np.stack((1/16+x1/2+x2/8+x1*(1-x2)/16+a/2+z,
                         1/16+x2/2+x1/8+x2*(1-x1)/16+a/4-z),axis=-1)
