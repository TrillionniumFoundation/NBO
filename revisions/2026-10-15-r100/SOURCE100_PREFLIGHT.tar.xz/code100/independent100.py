"""Independent rational terminal economy and active-set readout verification.
Does not import economy100, interval100 or the production feature constructor.
Linear algebra backend is shared NumPy/LAPACK; fitting algorithm and feature
construction are independently written. This limitation is explicit.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import combinations
import numpy as np

def q_terminal(x,a,alpha):
    x,y=map(F,x);a=F(a);alpha=F(alpha);delta=F(1,32)
    u=F(1,16)+x/2+y/8+x*(1-y)/16+a/2
    v=F(1,16)+y/2+x/8+y*(1-x)/16+a/4
    # Independent integration of the polynomial g(F(x,a,z)).
    def g(z):
        r,s=u+z,v-z
        return 2*((r-F(5,8))**2+(s-F(5,8))**2)+(r-s)**2/4+2*max(F(0),F(1,2)-r-s)**2
    c=g(F(0));b=(g(delta)-g(-delta))/(2*delta)
    aa=(g(delta)+g(-delta)-2*c)/(2*delta**2)
    center=max(-delta*(1-alpha),min(delta*(1-alpha),-b/(2*aa)))
    l=center-alpha*delta;r=center+alpha*delta
    def primitive(z):return aa*z**3/3+b*z*z/2+c*z
    risk=(primitive(delta)-primitive(-delta)-primitive(r)+primitive(l))/(2*delta*(1-alpha))
    S=(x-F(5,8))**2+(y-F(5,8))**2+(x-y)**2/4+2*max(F(0),F(1,2)-x-y)**2
    return S+a*a+4*a**4+F(15,16)*risk

def derivative_terminal(x,a,alpha):
    # Differentiation of separate polynomial branch by symmetric exact evaluations.
    # The fourth-degree action term contributes a known central-difference correction.
    # Caller must ensure the branch is unchanged at a +/- h.
    h=F(1,2**30);a=F(a)
    return (q_terminal(x,a+h,alpha)-q_terminal(x,a-h,alpha))/(2*h)-16*a*h*h

def scalar_gap_exact(a,A,s):
    a,A,s=map(F,(a,A,s));b=max(F(0),min(A,a-s/2))
    return -(s*(b-a)+(b-a)**2)

def features_independent(X,family):
    X=np.asarray(X);x=X[:,0];y=X[:,1];n=len(X)
    cols=[np.ones(n),x,y];gx=[np.zeros(n),np.ones(n),np.zeros(n)];gy=[np.zeros(n),np.zeros(n),np.ones(n)]
    if family=='quadratic':
        for u,v in ((1,0),(0,1),(1,1),(1,-1)):
            z=u*x+v*y;cols.append(z*z);gx.append(2*u*z);gy.append(2*v*z)
    else:
        dirs=[(1,0),(0,1)] if family=='spline' else [(1,0),(0,1),(.5,.5),(.5,-.5)]
        for u,v in dirs:
            low=min(0,u)+min(0,v);high=max(0,u)+max(0,v)
            for fraction in (.25,.5,.75):
                z=u*x+v*y-(low+fraction*(high-low));on=(z>0).astype(float)
                cols.append(np.maximum(z,0));gx.append(u*on);gy.append(v*on)
    return np.column_stack(cols),np.column_stack(gx),np.column_stack(gy)

def exhaustive_fit(X,y,g,family,directional):
    D,Dx,Dy=features_independent(X,family)
    if directional:D=np.vstack((D,Dx/8,Dy/8));y=np.concatenate((y,g[:,0]/8,g[:,1]/8))
    nonlinear=D.shape[1]-3;best=None;attempts=0
    for mask in range(1<<nonlinear):
        idx=[0,1,2]+[3+j for j in range(nonlinear) if (mask>>j)&1]
        v=np.linalg.lstsq(D[:,idx],y,rcond=None)[0];attempts+=1
        if len(v)>3 and np.min(v[3:]) < -1e-11:continue
        c=np.zeros(D.shape[1]);c[idx]=v
        c[3:]=np.maximum(0,c[3:]);err=float(np.sum((D@c-y)**2))
        if best is None or err<best[0]:best=(err,c)
    if best is None:raise ArithmeticError('no feasible active set')
    return best[1],best[0],attempts
