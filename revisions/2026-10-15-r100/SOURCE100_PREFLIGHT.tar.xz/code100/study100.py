"""Prospectively fixed R100 full-model continuation acquisition and decision study.
Run acquisition and validation before confirmation. JSONL rows are flushed after
every decision; exceptions retain tracebacks and previously completed rows.
"""
from __future__ import annotations
import argparse,hashlib,json,os,platform,resource,sys,time,traceback
from pathlib import Path
from itertools import product
import numpy as np
from scipy.optimize import lsq_linear,minimize_scalar
import scipy
from economy100 import Economy,BETA,DELTA,Counts
from certificate100 import Certifier,gamma_interval
from interval100 import I
from independent100 import exhaustive_fit,features_independent
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'results100'
PROTOCOL_SHA='9417def726024727caf8c265eff991b3e226ead2'

def dump(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,sort_keys=True,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def design(which):
    if which=='training':return np.array(list(product(np.arange(9)/8,repeat=2)))
    shift=3 if which=='validation' else 1
    return np.array(list(product((4*np.arange(4)+shift)/16,repeat=2)))
def feature_spec(family):
    if family=='quadratic':return [('square',u,v,0.) for u,v in [(1.,0.),(0.,1.),(1.,1.),(1.,-1.)]]
    dirs=[(1.,0.),(0.,1.)] if family=='spline' else [(1.,0.),(0.,1.),(.5,.5),(.5,-.5)]
    return [('hinge',u,v,min(0,u)+min(0,v)+f*(abs(u)+abs(v))) for u,v in dirs for f in [.25,.5,.75]]
def features(X,family):
    X=np.asarray(X);n=len(X);D=np.column_stack((np.ones(n),X))
    G=np.zeros((n,2,3));G[:,0,1]=1;G[:,1,2]=1
    for kind,u,v,k in feature_spec(family):
        z=X[:,0]*u+X[:,1]*v-k
        if kind=='square':values=z*z;slope=2*z
        else:values=np.maximum(0,z);slope=(z>0).astype(float)
        D=np.column_stack((D,values));gg=np.stack((slope*u,slope*v),axis=1)
        G=np.concatenate((G,gg[:,:,None]),axis=2)
    return D,G
class Model:
    def __init__(self,name,e,record=None,grid=None):self.name=name;self.e=e;self.record=record;self.grid=grid;self.feature_evaluations=0
    def values(self,X):
        X=np.asarray(X)
        if self.name=='online_semianalytic':return self.e.fast_value_grad(X)[0]
        if self.name=='grid_dp':
            xx=np.clip(X*8,0,8);ij=np.minimum(np.floor(xx).astype(int),7);r=xx-ij;i,j=ij[:,0],ij[:,1];u,v=r[:,0],r[:,1]
            f00=self.grid[i,j];f10=self.grid[i+1,j];f01=self.grid[i,j+1];f11=self.grid[i+1,j+1]
            self.feature_evaluations+=len(X)*4
            return np.where(u>=v,f00+(f10-f00)*u+(f11-f10)*v,f00+(f11-f01)*u+(f01-f00)*v)
        D,_=features(X,self.record['family']);self.feature_evaluations+=D.size
        return D@np.array(self.record['coefficients'])
    def propose(self,x):
        e=self.e;A=1/8+sum(x)/16;z=(np.arange(48)+.5)/48*(2*DELTA)-DELTA;k=int(48*(1-e.alpha))
        def value(a):
            X=e.fast_transition(np.array(x),a,z);v=self.values(X)
            e.counts.proposal_calls+=1
            return a*a+4*a**4+BETA*float(np.sort(v)[-k:].mean())
        aa=np.linspace(0,A,33);vv=[value(a) for a in aa];j=int(np.argmin(vv));best=(vv[j],float(aa[j]))
        if 0<j<32:
            fit=minimize_scalar(value,bounds=(aa[j-1],aa[j+1]),method='bounded',options={'xatol':1e-12,'maxiter':100})
            if fit.success and fit.fun<best[0]:best=(float(fit.fun),float(fit.x))
        return best[1]

def acquire():
    OUT.mkdir(exist_ok=True);X=design('training');records={};acq={};allchecks=[]
    for alpha in (.5,.75):
        e=Economy(alpha);t=time.perf_counter();cpu=time.process_time()
        y,g,a=e.fast_value_grad(X)
        intervals,grad,_=e.value_grad((I(X[:,0]),I(X[:,1])))
        if np.any(y<intervals.lo-1e-11) or np.any(y>intervals.hi+1e-11):raise AssertionError('training values disagree with enclosures')
        for j in (0,1):
            if np.any(g[:,j]<grad[j].lo-1e-10) or np.any(g[:,j]>grad[j].hi+1e-10):raise AssertionError('gradient training mismatch')
        label={'states':X.tolist(),'value':y.tolist(),'gradient':g.tolist(),'actions':a.tolist(),
               'value_enclosure':np.column_stack((intervals.lo,intervals.hi)).tolist(),
               'gradient_enclosure':np.stack([np.column_stack((v.lo,v.hi)) for v in grad],axis=1).tolist(),
               'counts':e.counts.json(),'wall_seconds':time.perf_counter()-t,'cpu_seconds':time.process_time()-cpu,
               'protocol_commit':PROTOCOL_SHA,'alpha':alpha}
        labelpath=OUT/f'labels-{alpha}.json';dump(labelpath,label)
        for family in ('quadratic','spline','relu','hinge'):
            for directional in (False,True):
                name=family+('_gradient' if directional else '_value');tt=time.perf_counter();cc=time.process_time()
                D,G=features(X,family);Y=y
                if directional:D=np.vstack((D,G[:,0,:]/8,G[:,1,:]/8));Y=np.concatenate((y,g[:,0]/8,g[:,1]/8))
                bounds=(np.array([-np.inf]*3+[0.]*(D.shape[1]-3)),np.full(D.shape[1],np.inf))
                fit=lsq_linear(D,Y,bounds=bounds,tol=1e-12,max_iter=1000,lsq_solver='exact')
                if not fit.success:raise ArithmeticError(f'{name} fitting failed: {fit.message}')
                coef=np.rint(fit.x*2**30)/2**30;coef[3:]=np.maximum(0,coef[3:])
                record={'family':family,'name':name,'directional':directional,'coefficients':coef.tolist(),
                        'coefficient_hex':[float(c).hex() for c in coef],'dictionary':feature_spec(family),
                        'label_sha256':sha(labelpath),'solver_status':int(fit.status),'iterations':int(fit.nit),
                        'optimality':float(fit.optimality),'fit_objective':float(np.sum((D@coef-Y)**2)),
                        'rank':int(np.linalg.matrix_rank(D)),'parameters':len(coef),'nonzero_nonlinear':int(np.count_nonzero(coef[3:])),
                        'fit_wall_seconds':time.perf_counter()-tt,'fit_cpu_seconds':time.process_time()-cc}
                path=OUT/'models'/f'{alpha}-{name}.json';dump(path,record)
                reload=json.loads(path.read_text());assert reload['coefficient_hex']==record['coefficient_hex']
                records[f'{alpha}:{name}']=reload
                # Independent feature design and exhaustive convex active-set fit.
                tverify=time.perf_counter();ic,err,attempts=exhaustive_fit(X,y,g,family,directional)
                Di,Dx,Dy=features_independent(X,family)
                np.testing.assert_array_equal(features(X,family)[0],Di)
                if record['fit_objective']>err+2e-8:raise AssertionError('independent global fitting objective mismatch')
                allchecks.append({'alpha':alpha,'arm':name,'independent_objective':err,'serialized_objective':record['fit_objective'],
                                  'active_sets_enumerated':attempts,'wall_seconds':time.perf_counter()-tverify,
                                  'nonlinear_nonnegative':bool(np.all(coef[3:]>=0)), 'result':'passed'})
        for suffix in ('value','gradient'):
            assert records[f'{alpha}:relu_{suffix}']['coefficient_hex']==records[f'{alpha}:hinge_{suffix}']['coefficient_hex']
        acq[str(alpha)]={'label_file':str(labelpath.relative_to(ROOT)),'label_sha256':sha(labelpath),
                         'label_counts':label['counts'],'label_wall_seconds':label['wall_seconds'],'label_cpu_seconds':label['cpu_seconds']}
    dump(OUT/'fitting-independent.json',allchecks);dump(OUT/'acquisition.json',acq)
    dump(OUT/'environment.json',{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,
         'platform':platform.platform(),'machine':platform.machine(),'processor':platform.processor(),
         'cpu_count':os.cpu_count(),'protocol_commit':PROTOCOL_SHA,
         'cpu_frequency':Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq').read_text().strip() if Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq').exists() else None,
         'clock_scope':'process-local descriptive; processor state not controlled; RSS is process high-water mark',
         'source_hashes':{p.name:sha(p) for p in sorted((ROOT/'code100').glob('*.py'))}})
    print('ACQUISITION COMPLETE',flush=True)

def models_for(alpha,e,only=None):
    names=[f'{f}_{s}' for f in ('quadratic','spline','relu','hinge') for s in ('value','gradient')]+['grid_dp','online_semianalytic']
    if only:names=[n for n in names if n==only]
    labels=json.loads((OUT/f'labels-{alpha}.json').read_text());grid=np.array(labels['value']).reshape(9,9)
    for name in names:
        if name in ('grid_dp','online_semianalytic'):yield Model(name,e,grid=grid)
        else:yield Model(name,e,json.loads((OUT/'models'/f'{alpha}-{name}.json').read_text()))

def run(phase,only=None,alpha_filter=None,tau_filter=None,tag=None):
    X=design('validation' if phase=='validation' else 'confirmation')
    filename=f'{phase}{"-"+tag if tag else ""}.jsonl';path=OUT/filename
    if path.exists():raise FileExistsError(f'preserve completed/failed run: {path}')
    with path.open('w') as f:
        for alpha in ([alpha_filter] if alpha_filter else [.5,.75]):
            for tau in ([tau_filter] if tau_filter else [2**-8,2**-10,2**-12]):
                for template in models_for(alpha,Economy(alpha),only):
                    for row_id,x in enumerate(X):
                        e=Economy(alpha);m=Model(template.name,e,template.record,template.grid);c=Certifier(e)
                        t=time.perf_counter();cpu=time.process_time();proposal=m.propose(x)
                        after_proposal=e.counts.json();tprop=time.perf_counter()-t
                        out=c.solve(x,proposal,tau)
                        tdecision=time.perf_counter()-t;ccdecision=time.process_time()-cpu;decision_counts=e.counts.json()
                        # Charge a realized terminal call too; z=0 is a fixed service-cost probe,
                        # not a replacement for the continuous risk law used in value intervals.
                        successor=e.fast_transition(x,out['action'],0.)
                        terminal_action,terminal_allowance=e.terminal_policy(successor)
                        complete_counts=e.counts.json();tcomplete=time.perf_counter()-t;cpucomplete=time.process_time()-cpu
                        terminal_work={k:complete_counts[k]-decision_counts[k] for k in complete_counts}
                        audit_t=time.perf_counter();before=e.counts.json()
                        obj,tail=c.objective(x,out['action'],128)
                        last=out['attempts'][-1];vcoarse,_=c.objective(x,out['action'],last['n'],tuple(last['tail']))
                        gvalue=float((I(last['gamma'])+I(float(vcoarse.hi))-float(vcoarse.lo)+BETA*2**-20).hi)
                        audit_counts={k:e.counts.json()[k]-before[k] for k in before}
                        row={'phase':phase,'protocol_commit':PROTOCOL_SHA,'alpha':alpha,'tau':tau,'arm':m.name,'row_id':row_id,'state':x.tolist(),
                             **out,'objective_exact_future':obj.pair(),
                             'complete_policy_objective':[float(obj.lo),float((I(float(obj.hi))+BETA*2**-20).hi)],
                             'same_mesh_value_support_regret_upper':gvalue,'same_mesh_value_support_admitted':gvalue<=tau,
                             'proposal_counts':after_proposal,'decision_counts':decision_counts,'complete_counts':complete_counts,
                             'terminal_action_probe':terminal_action,'terminal_allowance_probe':terminal_allowance,'terminal_work_probe':terminal_work,
                             'feature_evaluations':m.feature_evaluations,'proposal_wall_seconds':tprop,
                             'decision_wall_seconds':tdecision,'decision_cpu_seconds':ccdecision,
                             'complete_wall_seconds':tcomplete,'complete_cpu_seconds':cpucomplete,
                             'verification_counts':audit_counts,'verification_wall_seconds':time.perf_counter()-audit_t,
                             'rss_process_highwater_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
                        f.write(json.dumps(row,sort_keys=True,allow_nan=False)+'\n');f.flush()
                    print(phase,alpha,tau,template.name,'COMPLETE',flush=True)
    return path

def select():
    rows=[json.loads(l) for l in (OUT/'validation.jsonl').read_text().splitlines()];selections=[]
    for alpha in (.5,.75):
        label=json.loads((OUT/f'labels-{alpha}.json').read_text());lw=sum(label['counts'][k] for k in ('terminal_point_evaluations','terminal_box_evaluations'))
        for tau in (2**-8,2**-10,2**-12):
            scores=[]
            for name in sorted({r['arm'] for r in rows}):
                rr=[r for r in rows if (r['alpha'],r['tau'],r['arm'])==(alpha,tau,name)]
                if len(rr)!=16:raise AssertionError('incomplete validation design')
                work=sum(r['complete_counts']['terminal_point_evaluations']+r['complete_counts']['terminal_box_evaluations'] for r in rr)
                work+=0 if name=='online_semianalytic' else lw
                scores.append({'arm':name,'original_oracle_work':work,'qualified':all(r['qualified'] for r in rr)})
            eligible=[r for r in scores if r['qualified']]
            winner=min(eligible,key=lambda r:(r['original_oracle_work'],r['arm']))['arm'] if eligible else None
            selections.append({'alpha':alpha,'tau':tau,'winner':winner,'scores':scores})
    dump(OUT/'selection-before-confirmation.json',{'protocol_commit':PROTOCOL_SHA,'validation_sha256':sha(OUT/'validation.jsonl'),'selections':selections})

def main():
    ap=argparse.ArgumentParser();ap.add_argument('command',choices=['acquire','validation','confirmation','timing','select']);ap.add_argument('--only');ap.add_argument('--alpha',type=float);ap.add_argument('--tau',type=float);ap.add_argument('--tag');args=ap.parse_args()
    if args.command=='acquire':acquire()
    elif args.command=='select':select()
    else:
        if args.command=='confirmation' and not (OUT/'selection-before-confirmation.json').exists():raise RuntimeError('validation selection must be sealed first')
        run(args.command,args.only,args.alpha,args.tau,args.tag)
if __name__=='__main__':
    try:main()
    except Exception:
        OUT.mkdir(exist_ok=True);p=OUT/('failure-'+str(time.time_ns())+'.log');p.write_text(traceback.format_exc());raise
