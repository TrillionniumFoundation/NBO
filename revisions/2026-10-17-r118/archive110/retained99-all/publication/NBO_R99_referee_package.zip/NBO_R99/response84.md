# Response to the Referee
## Neural Bellman Operators — Revision R84

We thank the referee for the detailed assessment of the distinction between a correct safeguarded computation and an economically informative Neural Bellman Operator. We revise the original paper, retaining its title, economic primitives, constructive own-future continuation, feasible action witnesses and original Bellman optimum. The controlling advisory report is dated 11 October 2026, on review commit `4b27b56f4514f6c1d77b69fe707f7202f8b06b19`, and reviews R67 at `eacd3e217ae1e2e9ea6e154b48da7d103159d051`. It is not represented as an editorial decision of the Econometric Society.

The report predates the subsequent attained-controller and original-law cost developments. R69–R73 execute qualification and protected reuse; R77–R81 connect complete constructed controllers, higher-precision cost inference, affine calibration and exact optimization barriers. R82–R83 price the possible acquired-action changes and derive economic stopping regions. This revision starts from the completed source-bound R83 recovery at `0f807677ac6f2a47455f49f061ddbc9710b28738`, not from an obsolete manuscript wrapper. Those sources, their complete records, the interrupted R82 calculation and every unfavorable result remain preserved.

R84 adds a further substantive restriction: a qualified output has one readout vector. An alternative must win its complete feasible menu, and choices at different cells must be compatible with that same vector. The new main theorem transfers exact certificates for these restrictions into original-law policy-cost bounds. Its proof is in the article. The Numerical and Development Appendix derives the rational qualification, separation and assignment duals, gives strict-improvement and relaxation-gap examples, and reports every declared numerical comparison. This extends the original NBO optimization-to-economic-decision chain rather than substituting a different paper on optional search proposals.

## M1 / B1: What belongs to the NBO construction?

The paper separates the constructive operator, the representation-neutral safeguard and the qualification of the attained continuation. Correctness of the safeguard is not made artificially neural. The NBO nevertheless remains a substantive constructed object: its own-future continuation, feasible witnesses, affine–ReLU realization and primitive error account determine an implementable policy. The latest calculations concern the policy cost of classes of approximately optimized attained continuations, not merely the location of an optional extra Bellman probe.

The new winner constraints use the actual feature representation and one shared readout. They can be applied to both ReLU and conventional Bernstein continuations, which is necessary for a meaningful comparison. A stronger common theorem is not presented as evidence of exclusive neural superiority. The original title and model are retained because the result directly strengthens the economic qualification of the original construction.

## M2 / B2: Matched conventional comparisons and full-menu qualification

The retained factorial experiment compares both bases, both qualification rules and both acquisition resolutions under their declared information and implementation contracts. It retains the earlier ReLU advantage under legacy qualification and the reversed matched ordering under affine-calibrated qualification. The latter is not hidden by selecting a different baseline. Construction clocks with different fitting or ablation boundaries are not asserted to be a universal matched speed comparison.

R84 gives every one of the 976 previously admitted alternatives a qualification problem against all 32 competing actions in its unchanged menu. The prior reference-only barrier remains a valid lower bound and is intersected with the new bound. Thus the new calculation cannot obtain a favorable comparison by deleting feasible actions or altering the fitted labels. An action that beats the reference but loses to another feasible menu member need not be retained as a possible implemented choice.

The shared-readout calculation then qualifies 1,572 predetermined cross-cell pairs. It produces a stricter economic interval than full-menu qualification in fifteen of the 24 model–tolerance records. The four models and six tolerances are all reported, including unchanged and unresolved cases. The exact finite design, cost-directed pair ordering and development pilot are disclosed; this is not portrayed as a prospective random benchmark.

## M3 / B3: Predictable validation and post-selection

The predictable-evaluation and protected-query theorems remain in their original sections with their filtration, context-law and validation requirements. They are not replaced by an assumption that recursively produced contexts are independent. The intervening qualification and readout experiments also remain in the compiled record.

The new theorem addresses a different selection issue. Conditional on the original simultaneous attained-policy cost event, every valid winner, joint-event and assignment inequality is deterministic. The resulting comparison therefore holds for every readout in the stated objective sublevel and for all allowances simultaneously. Inspecting these valid bounds does not require a union bound over an uncountable coefficient class or a new independent cost sample. Changing the labels, future actor, initial law or estimand is outside that implication unless separately qualified.

This establishes an optimization-to-decision guarantee for outputs of the declared fixed-feature problem. It does not substitute that guarantee for prospective work-loss validation of a newly fitted predictor under a different context distribution.

## M4 / B4: Reuse, complete work and prospective evidence

The longer protected-reuse catalogues already deposited after R67 remain available, together with failed admissions, unfavorable timing comparisons and their exact charging boundaries. The new calculation does not reclassify their observations or infer a stable neural amortization advantage from an isolated late crossing.

R84 adds a separately measured use of existing evidence. Once attained controllers, actionwise integrals and their cost intervals have been purchased, new full-menu and common-readout certificates can improve the economic decision without another fit or simulation. The scientific process records 976 singleton qualification problems, 1,572 joint-event problems, the assignment problems at every allowance, all solver statuses, phase times and peak memory. Its recorded complete interpreter time is approximately 104.699 seconds on the stated ARM runner, including imports, input reads, computations, durable records and shutdown. That is an incremental qualification cost, not the complete cold-start cost of producing all prerequisite evidence.

The previous fitting, integration and statistical services retain their original clocks. Independent checking and publication have separate clocks. One recorded execution is not treated as a timing distribution, and differences in these qualification times are not used to claim an optimizer or representation speed ranking.

## M5 / B5: Useful policy-cost precision and an economic decision

The original-law R80 experiment already increases the direct cost family to 524,288 common bin rows and 94 declared estimands, with conditional integration, sampling uncertainty, continuous-bin uncertainty and arithmetic enclosure accounted for separately. R84 does not add those rows again. It refines the deterministic optimizer-class transfer applied to that already covered family.

At excess objective 1/4096, coarse-minus-fine Bernstein has an inherited actionwise interval crossing zero. The new compatible interval is strictly positive. Consequently the finer controller has lower original-law cost for every pair of readouts in the two qualified classes, even though the readouts need not reproduce the attained action arrays exactly. The article reports the outward interval and the entire supported refinement-fee range. Because smaller objective sublevels are contained in the largest one, the conclusion also applies to every smaller allowance, not just the six displayed tolerances.

The matched fine ReLU-minus-Bernstein comparison at 1/65536 remains strictly positive and has a narrower compatible interval. This preserves the calibrated Bernstein advantage rather than inventing a new neural ranking. Coarse-ReLU comparisons that remain inconclusive and the larger-tolerance unresolved fine-basis cases remain in the complete tables. The declared equivalence margin is tested using exact endpoints, not rounded decimal appearances. A tighter certificate is distinguished from a newly observed improvement of the attained controller itself.

## M6 / B6: Vector controls and the horizon problem

The vector-control construction, derivative and simplex results, two-shock experiments and large descendant-tree growth are retained under their existing assumptions. The new theorem applies whenever the fixed-continuation conditional contrasts can be enclosed and the first-date acquired action has the declared finite menu. Its proof does not depend on a one-dimensional readout coefficient vector or on a scalar cost approximation.

The newly executed study remains the original two-state, two-date investment economy with a fixed terminal actor. It adds neither a trained two-output vector benchmark nor an independent regeneration of the largest vector tree. The theorem is not used to disguise that distinction. Jointly refitting future controllers or claiming favorable high-dimensional horizon scaling would require additional work beyond these fixed-continuation certificates. The original vector results and their adverse runtime evidence remain compiled, rather than being deleted to simplify the new claim.

## M7 / B7: Independent arithmetic and preserved failures

The full R83 recovery and the interrupted R82 execution are preserved separately. The old identity-lookup exception and the earlier path-enclosure aliasing counterexample remain part of the development record. The publication verification reruns the inherited relevant suites and the independently implemented original-law integrations; original service clocks are not replaced by replay clocks.

For the new calculation, the independent checker imports neither the production optimizer nor its qualification module. It reconstructs exact feature means from the separate antiderivative implementation, all winner-menu inequalities, the coefficient-box support dual, every joint-event separation, all conflict rosters and the final cost transfers. It verifies 2,548 qualification certificates and 16,548 assignment-dual inequalities. All 36 pairwise class comparisons are checked.

There are 104 numerical infeasibility statuses. Each is accompanied by a strictly positive rational box-separation certificate; an infeasible solver flag alone is never sufficient. If such a certificate were absent, the event would retain its independently valid lower qualification bound and would not be removed merely because optimization failed. Regression tests exercise this fallback explicitly, along with forged economic-dual values, duplicate sparse indices, negative multipliers, strict boundaries and missing assignment coverage.

Full independent qualification of these new objects is not described as full independent reexecution of the largest historical vector computation. The respective audit scopes are kept distinct.

## M8 / B8: What is guaranteed about fitting?

Verifier return, numerical fitting performance and population reliability remain separate objects. All historical fitting warnings and seed-level observations are retained. The current study adds zero fitting attempts and makes no claim about unrestricted hidden-layer optimization success.

The new deterministic implication is stronger than an empirical success-frequency assertion for the declared readout problem. If a feasible output has primal value F(theta), an independently valid dual value d no larger than the optimum, and primal–dual gap at most epsilon, then it belongs to the covered objective class. The classwide policy-cost interval and any supported economic decision apply to that output regardless of which admissible coefficient vector the fitting algorithm returned. The shared-readout restrictions improve the decision by ruling out impossible combinations, not by assuming that an unobserved optimizer follows a favorable path.

## M9 / B9: Economic interpretation, refinement charges and basis reversal

The added positive result is a robust investment-controller refinement decision. The fine Bernstein class is cheaper than the coarse Bernstein class over the stated nonzero optimization allowance. Subtracting a supplied additional refinement charge from both difference endpoints gives the supported, unresolved and opposite-choice regions. The exact normalized fee ceiling is generated from the verified lower endpoint and printed with outward rounding.

This conclusion uses the original investment law and actual implemented-policy cost. It is not a comparison between two all-state error bounds, and it does not use simulated evaluation rows as economic deployments. The inherited priced-selection and deployment-allocation results retain separate loss units, information prices, compute charges and deployment counts. No dollar calibration, estimated installation charge or universal neural purchase recommendation is invented.

The observed reversal between legacy and calibrated basis rankings remains scientifically relevant: qualification can change which representation is economically preferable. The paper develops that positive mechanism and its optimizer-class robustness rather than attaching an unconditional superiority claim to ReLU.

## M10 / B10: Exposition, scope and substantive preservation

The main text now proceeds from attained NBO continuations and their original-optimum accuracy through actionwise qualification, economic stopping and common-readout compatibility. The new theorem includes its complete proof in the article. Exact dual construction, complexity accounting, counterexamples and the exhaustive new catalogue are in the Numerical and Development Appendix. Core technical-supplement sections stay in their existing locations.

Every inherited active section is retained byte-identically, compiled once and in its original document. Original wrappers and historical PDFs are preserved separately and never relabeled as new compilations. The title, author information, economic primitives, historical records and older remote branches are unchanged. The active manuscript is extended without arbitrary deletion to meet an obsolete internal page target; its actual page count is reported by the new release audit.

The historical diffusion, recursive-preference, endogenous-preference, temporal-self and game results retain their own assumptions in the companion material. The present fixed-continuation expected-cost theorem is not silently applied to nonlinear recursive preferences. Maintaining this hypothesis discipline preserves the original research program without changing the topic or claiming an unproved extension.

## Verification and submission package

The R84 release contains ordinary main, supplement, numerical appendix and response sources; the full-menu and common-readout theorem; all exact dual and economic records; the frozen study design; inherited evidence and failures; and the complete verification logs. The release requires the inherited unskipped suites, the new exact regressions, independent certificate checking, relevant full-bin replay, four-document compilation and a clean archive rebuild. Visual inspection is a separately recorded check of the actual PDF hashes, not an implication of a successful compiler.

The principal addition is a constructive common-readout restriction that sharpens economic accuracy and identifies a new classwide refinement decision in the original NBO economy. It is supported by a complete deterministic catalogue and independent rational verification. Universal neural superiority, unqualified fitting reliability, empirically calibrated fees and unexecuted large-vector validation are not inferred from that result.
