"""Bounded infrastructure checks on tiny synthetic Git repositories only."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile

SOURCE = Path('/workspace/scratch/913249553838/NBO/revisions/2026-10-20-r121/verification121')
OUT = Path('/workspace/scratch/913249553838/audit121/experiments/transport_preparation_synthetic_attempt02')
PREFIX = Path('revisions/2026-10-20-r121')
OUT.mkdir(exist_ok=False)
started = time.perf_counter()
commands = []
checks = []


def run(argv, cwd=None, expected=0):
    before = time.perf_counter()
    result = subprocess.run(list(map(str, argv)), cwd=cwd, capture_output=True,
                            env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
    index = len(commands)
    log = OUT / f'command-{index:02d}.log'
    log.write_bytes(result.stdout + result.stderr)
    commands.append(dict(argv=list(map(str, argv)), cwd=str(cwd) if cwd else None,
        exit_code=result.returncode, expected=expected, elapsed_seconds=time.perf_counter()-before,
        log=log.name, log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    (OUT / 'COMMANDS121.json').write_text(json.dumps(commands, indent=2) + '\n')
    assert result.returncode == expected, (argv, result.returncode, log.read_text())
    return result.stdout.decode().strip()


def put(root, name, value):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(value if isinstance(value, bytes) else value.encode())
    return path


def commit(repo, message):
    run(['git', 'add', '.'], repo)
    run(['git', '-c', 'user.name=Synthetic Fixture', '-c', 'user.email=fixture@example.invalid',
         'commit', '-m', message], repo)
    return run(['git', 'rev-parse', 'HEAD'], repo)


repo = OUT / 'fixture'
repo.mkdir()
run(['git', 'init', '-q'], repo)
native = repo / PREFIX
science = put(native, 'science.py', '# Synthetic byte fixture; never imported or executed.\n')
put(native, 'SOURCE_FREEZE121.json', json.dumps({'scientific_files': {
    'science.py': hashlib.sha256(science.read_bytes()).hexdigest()}}))
put(native, 'tracked.txt', 'original tracked text\n')
put(native, 'tracked.bin', b'\0original tracked binary')
put(native, 'tracked-cache/__pycache__/historical.txt', 'Deliberately tracked historical bytes.\n')
for name in ('prepare_transport121.py', 'assemble_transport121.py'):
    put(native, 'verification121/' + name, (SOURCE / name).read_bytes())
base = commit(repo, 'Synthetic parent for byte transport checks')
helper = native / 'verification121/prepare_transport121.py'
put(native, 'tracked.txt', 'changed tracked text\n')
put(native, 'tracked.bin', b'\0changed tracked binary')
put(native, 'results121/raw-trace.jsonl', '{"status":"synthetic","trace":true}\n')
put(native, 'results121/failed-attempt/FAILED121.jsonl', '{"status":"synthetic-failed"}\n')
put(native, 'archive-old/referee-ready121.zip', b'Historical failed-container fixture, not a current package.')
put(native, 'build/ECTA.fls', 'PWD /synthetic-only\n')
put(native, 'notes/utf8.txt', 'Small UTF-8 fixture: α.\n')
put(native, 'temp.tmp', 'Generated non-evidence fixture.\n')
put(native, '__pycache__/cache.pyc', b'Untracked cache fixture')
put(native, 'SOURCE_READY121.json', '{}\n')
put(native, 'SOURCE_PDF_MANIFEST121.json', '{}\n')
put(native, 'referee-ready121.zip', b'Current final-container fixture excluded from its own snapshot.')
put(native, 'transport121/bundles/old-fixture/REQUEST121.json', '{}\n')
put(native, 'new-executable.sh', '#!/bin/sh\nexit 0\n').chmod(0o755)
exclude = OUT / 'transient-exclusions.json'
exclude.write_text(json.dumps({'kind': 'nbo-r121-transient-exclusions-v1', 'files': [
    {'path': 'temp.tmp', 'reason': 'Synthetic generated temporary bytes only.',
     'not_authored_or_scientific_evidence': True}]}))
classified = OUT / 'classify'
run([sys.executable, helper, 'classify', '--repository', repo, '--base-commit', base,
     '--transient-exclusions', exclude, '--output-dir', classified])
census = json.loads((classified / 'NATIVE_CLASSIFICATION121.json').read_text())
rows = {row['path']: row for row in census['files']}
assert rows['tracked.txt']['disposition'] == rows['tracked.bin']['disposition'] == 'changed_tracked_direct_write'
assert rows['tracked.txt']['direct_write_kind'] == 'utf8_text'
assert rows['tracked.bin']['direct_write_kind'] == 'binary_blob'
assert rows['tracked-cache/__pycache__/historical.txt']['disposition'] == 'unchanged_tracked'
assert rows['__pycache__/cache.pyc']['disposition'] == rows['temp.tmp']['disposition'] == 'excluded_non_authored_generated'
assert rows['SOURCE_READY121.json']['disposition'] == rows['SOURCE_PDF_MANIFEST121.json']['disposition'] == 'deferred_control'
assert rows['referee-ready121.zip']['disposition'] == 'excluded_non_authored_generated'
assert rows['archive-old/referee-ready121.zip']['disposition'] == 'new_transportable_native'
assert rows['new-executable.sh']['disposition'] == 'new_executable_direct_write'
assert rows['results121/raw-trace.jsonl']['disposition'] == rows['results121/failed-attempt/FAILED121.jsonl']['disposition'] == 'new_transportable_native'
assert rows['build/ECTA.fls']['disposition'] == 'new_transportable_native'
checks.append('Complete classification preserves raw/failure/build/historical bytes and separates exact controls/caches/direct writes.')
extra = OUT / 'extra-paths.txt'
extra.write_text(PREFIX.as_posix() + '/science.py\n# Explicit same-byte parent member\n')
for attempt in ('pack-a', 'pack-b'):
    run([sys.executable, helper, 'pack', '--repository', repo, '--base-commit', base,
         '--bundle-id', 'synthetic-bundle', '--include-list', classified / 'TRANSPORT_INCLUDE121.json',
         '--include-list', extra, '--output-dir', OUT / attempt])
archive_a, archive_b = (OUT / 'pack-a/payload.zip').read_bytes(), (OUT / 'pack-b/payload.zip').read_bytes()
assert archive_a == archive_b
assert (OUT / 'pack-a/bundle/REQUEST121.json').read_bytes() == (OUT / 'pack-b/bundle/REQUEST121.json').read_bytes()
checks.append('Repeated explicit JSON and text-list packing produces byte-identical ZIP and REQUEST.')
with zipfile.ZipFile(OUT / 'pack-a/payload.zip') as zipped:
    for member in zipped.infolist():
        expected = zipfile.ZIP_STORED if Path(member.filename).suffix in {'.gz', '.png', '.pdf', '.zip'} else zipfile.ZIP_DEFLATED
        assert member.compress_type == expected
run([sys.executable, helper, 'pack', '--repository', repo, '--base-commit', base,
     '--bundle-id', 'synthetic-store', '--compression-policy', 'store',
     '--include-list', classified / 'TRANSPORT_INCLUDE121.json', '--include-list', extra,
     '--output-dir', OUT / 'pack-store'])
with zipfile.ZipFile(OUT / 'pack-store/payload.zip') as zipped:
    assert all(member.compress_type == zipfile.ZIP_STORED for member in zipped.infolist())
checks.append('Default mixed policy matches stored-suffix/deflate-6 routing; explicit store mode retains uncompressed member policy.')
request = json.loads((OUT / 'pack-a/bundle/REQUEST121.json').read_text())
assert set(row['path'] for row in request['files']) == {PREFIX.as_posix() + '/' + name for name in (
    'results121/raw-trace.jsonl', 'results121/failed-attempt/FAILED121.jsonl',
    'archive-old/referee-ready121.zip', 'build/ECTA.fls', 'notes/utf8.txt', 'science.py')}
assembly = OUT / 'assembly-fixture'
run(['git', 'clone', '-q', '--no-hardlinks', repo, assembly])
dest = assembly / PREFIX / 'transport121/bundles/synthetic-bundle'
shutil.copytree(OUT / 'pack-a/bundle', dest)
transport = commit(assembly, 'Synthetic T adds exactly one request')
run([sys.executable, assembly / PREFIX / 'verification121/assemble_transport121.py',
     '--repository', assembly, '--transport-commit', transport, '--request', 'auto',
     '--stage-list', OUT / 'assembly-stage-paths.bin'])
receipt = json.loads((dest / 'ASSEMBLY121.json').read_text())
assert receipt['scientific_executions'] == 0 and receipt['status'] == 'verified_and_materialized'
for row in request['files']:
    assert (assembly / row['path']).read_bytes() == (repo / row['path']).read_bytes()
checks.append('Unmodified real assembly helper accepts synthetic transport and materializes every exact declared byte.')
run([sys.executable, helper, 'pack', '--repository', repo, '--base-commit', base,
     '--bundle-id', 'changed-blocked', '--include', 'tracked.txt', '--output-dir', OUT / 'blocked-changed'], expected=1)
assert not (OUT / 'blocked-changed/bundle/REQUEST121.json').exists()
checks.append('Changed tracked source cannot become an assembly request; failed prefix retained.')
run([sys.executable, helper, 'pack', '--repository', repo, '--base-commit', base,
     '--bundle-id', 'executable-blocked', '--include', 'new-executable.sh', '--output-dir', OUT / 'blocked-executable'], expected=1)
assert not (OUT / 'blocked-executable/bundle/REQUEST121.json').exists()
checks.append('New executable is routed to direct Git write rather than silently losing mode in assembly.')
saved = (native / 'tracked.bin').read_bytes()
(native / 'tracked.bin').unlink()
run([sys.executable, helper, 'classify', '--repository', repo, '--base-commit', base,
     '--transient-exclusions', exclude, '--output-dir', OUT / 'missing-tracked'], expected=2)
put(native, 'tracked.bin', saved)
assert json.loads((OUT / 'missing-tracked/PREPARATION121.json').read_text())['status'] == 'classified_with_blockers'
checks.append('Missing tracked data produces explicit blocking census and nonzero exit without deletion authorization.')
bad = OUT / 'bad-transient.json'
bad.write_text(json.dumps({'kind': 'nbo-r121-transient-exclusions-v1', 'files': [
    {'path': 'results121/raw-trace.tmp', 'reason': 'Attempted exclusion of evidence.',
     'not_authored_or_scientific_evidence': True}]}))
run([sys.executable, helper, 'classify', '--repository', repo, '--base-commit', base,
     '--transient-exclusions', bad, '--output-dir', OUT / 'blocked-evidence-exclusion'], expected=1)
checks.append('A temporary-name declaration cannot exclude a scientific result or trace path.')
result = dict(status='passed_bounded_synthetic_infrastructure_checks', checks=checks,
    helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),
    archive_fixture_bytes=len(archive_a), elapsed_seconds=time.perf_counter()-started,
    original_repository_mutated=False, actual_scientific_data_read=False,
    scientific_evaluations=0, native_evidence_hashing_or_packing_performed=False,
    synthetic_repositories_and_failed_prefixes_retained=True)
(OUT / 'RESULT121.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, sort_keys=True))
