"""New saved-statistic gate arithmetic only, with no empirical records read."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,importlib.util,json,math,sys,time,traceback

ROOT=Path('/workspace/scratch/913249553838')
SOURCE=ROOT/'NBO/revisions/2026-10-20-r121/code121/report121.py'
OUT=ROOT/'audit121/experiments/reporting_gate_synthetic_attempt01'


def write(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n')


def main():
    OUT.mkdir(parents=True,exist_ok=False);start=time.time();h=hashlib.sha256(SOURCE.read_bytes()).hexdigest();checks=0
    write('START.json',{'kind':'pure synthetic saved-statistic gate arithmetic','source_sha256':h,
        'started_unix':start,'empirical_records_read':False,'scientific_evaluations':0})
    try:
        spec=importlib.util.spec_from_file_location('r121_report_gate_synthetic_only',SOURCE)
        mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
        for k in (1,32,64):
            delta=F(sum(math.comb(64,j) for j in range(k,65)),2**64)
            record={'successes':k,'lower':F(1,2),'inversion_upper':F(1,2)+F(1,2**48),'bisections':48}
            assert mod.check_saved_cp(record,k,delta)==(record['lower'],record['inversion_upper']);checks+=1
        assert mod.check_saved_cp({'successes':0,'lower':0,'inversion_upper':0,'bisections':0},0,F(1,11200))==(0,0);checks+=1
        rejected=0
        for bad in ({'successes':1,'lower':F(1,2),'inversion_upper':F(1,2),'bisections':48},
                    {'successes':0,'lower':0,'inversion_upper':0,'bisections':48}):
            try:mod.check_saved_cp(bad,bad['successes'],F(1,11200))
            except ArithmeticError:rejected+=1
        assert rejected==2;checks+=2
        pairs=[(F(-1,4),F(1,3))]*64
        rec={'sample_mean_lower':F(-1,4),'sample_mean_upper':F(1,3),
             'population_mean_lower':F(-7,20),'population_mean_upper':F(13,30)}
        assert mod.check_saved_mean(rec,pairs,F(-1),F(1),F(1,10))==rec;checks+=1
        forbidden={'numpy','scipy','investment94','continuum94','kernel108','models121','labels121','exact121','stats121'}
        assert not forbidden.intersection(sys.modules);checks+=1
        assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==h;checks+=1
        result={'status':'executed','exit_code':0,'checks':checks,'expected_invalid_records_rejected':2,
            'source_sha256':h,'elapsed_seconds':time.time()-start,'empirical_records_read':False,
            'economic_evaluations':0,'new_statistics_on_real_data':0,'training_or_sampling':0}
        write('RESULT.json',result);print(json.dumps(result,sort_keys=True))
    except BaseException:
        write('FAILED.json',{'status':'failed','checks':checks,'traceback':traceback.format_exc(),'source_sha256':h});raise


if __name__=='__main__':main()
