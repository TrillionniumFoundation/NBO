# R121 postprocess and publication interface handoff

This is a prospective source-only handoff. No command below was executed by
this review. The primary campaign and its five serial timing children must
finish before any independent evaluation, verification, hashing or build is
started. Actual failed attempts remain at their original paths and require
fresh disclosed output paths; never reuse an exclusive output directory.

## Immutable identities

```bash
cd /workspace/scratch/913249553838/NBO/revisions/2026-10-20-r121
NBO121_F=16bf21334efcbc719b83e2ccf10e8527f8b956f2
NBO121_M=796c5f2badf68b051ac6c144884c0e61b87faf5e
NBO121_D=68eae434c0e61fb1a61c3271c651c83c28619a07
```

The following launcher paths are proposed fresh paths under the discoverable
`results121` ledger. If a parent-owned launcher already uses a different fresh
subdirectory, retain it; the reporting interface matches the actual command's
scientific output path, not a required launcher directory spelling.

## Original independent evaluation, then frozen statistics

```bash
python code121/launch121.py \
  --output results121/launches/independent-attempt01 \
  -- python code121/independent121.py \
  --source-commit "$NBO121_F" \
  --primary results121/primary-attempt01/records121.jsonl \
  --output results121/independent-attempt01
```

Only after that actual command exits successfully:

```bash
python code121/launch121.py \
  --output results121/launches/stats-attempt01 \
  -- python code121/stats121.py \
  --source-commit "$NBO121_F" \
  --primary results121/primary-attempt01/records121.jsonl \
  --independent results121/independent-attempt01/comparisons121.jsonl \
  --output results121/stats-attempt01
```

The three byte-stable statistical products are exactly:

- `ORIGINAL_OPTIMUM121.jsonl`
- `POLICY_GROUPS121.jsonl`
- `LOSS_CONTRASTS121.jsonl`

`INPUTS121.json` and `EXECUTION121.json` retain actual runtime/custody metadata
and are not asserted to replay byte-for-byte.

## Complete deterministic reporter

```bash
python code121/launch121.py \
  --output results121/launches/report-attempt01 \
  -- python code121/report121.py \
  --source-commit "$NBO121_F" \
  --actor-commit "$NBO121_M" \
  --state-commit "$NBO121_D" \
  --output results121/report-attempt01
```

The reporter checks the completed acquisition5, acquisition9, training-audit5,
training-audit9, states, primary, independent and stats attempt01 directories.
Every selected acquisition/audit/primary/independent/statistics attempt needs
its original completed `LAUNCH121.json` and matching `stdout.log` somewhere
under `results121`. The reporter's own launch is explicitly excluded from that
scientific launcher census.

Generated TeX paths are:

- `results121/report-attempt01/new121/results121.tex`
- `results121/report-attempt01/new121/development121_results.tex`

They do not automatically replace the manuscript agent's
`new121/numerical121.tex`. The agent integrates all actual signed contrasts,
58 cells and cost results into the author text while retaining the generated
bytes in the report attempt. The manifest's `stable_replay_files` is a list
of `{path, bytes, sha256, git_blob}` objects; the CI requires the complete same
path set and bytes, not selected files.

Standalone saved-record auditing is available if needed, but the final CI
wrapper already runs it:

```bash
python verification121/study_integrity121.py \
  --source-commit "$NBO121_F" \
  --actor-commit "$NBO121_M" \
  --state-commit "$NBO121_D" \
  --output ci121/saved-record-audit-attempt01
```

## Final source build and local candidate gate

After the manuscript, supplement, development companion and response are
complete, capture the strict original source build:

```bash
python code121/launch121.py \
  --output provenance121/launches/final-source-build-attempt01 \
  -- python build121.py \
  --receipt-dir provenance121/final-source-build-attempt01
```

The timestamped `BUILD_RECEIPT121.json` under that receipt directory is the
`SOURCE_READY121.source_build_receipt`; its four actual PDF entries supply the
marker snapshot. Do not choose a draft or diagnostic receipt. All build command
logs and actual source dependencies must be retained. The response now uses
the same three guarded PDF metadata controls as the other documents, in
addition to the builder's fixed source epoch; no cross-environment byte
reproducibility result is asserted until it is executed.

After creating the agreed RUNS, candidate manifest and ready marker with
actual hashes:

```bash
python verification121/ci121.py \
  --precommit \
  --output ci121/local-attempt01
```

This deliberately reports `passed_local_precommit_package` only on actual
success. Add `--skip-build` only for an evidence-only gate; that reports
`passed_local_precommit_evidence_only` and does not certify PDF reproduction.
Build-enabled output must remain under native R121. Keep CI replay outputs and
their support launchers out of the original `results121` scientific ledger.

## T, E0 and final S publication

1. Determine changed, missing and identical native files from the actual remote
   parent Git tree. Publish changed tracked text files directly in T. A
   transport bundle may include only absent or already byte-identical native
   paths; assembly refuses changed overwrites and deletions.
2. Create a fresh `transport121/bundles/<bundle_id>/`. Its ZIP has no archive
   comment, no directory members, exact full repository-relative member names,
   and 8 MiB consecutive parts `payload.zip.part0000`, etc. REQUEST declares
   each member's bytes, SHA256 and Git blob as well as archive/part identities.
3. T adds exactly one new REQUEST relative to its single parent. Old requests
   remain untouched. Do not include SOURCE_READY in T and do not use a skip-CI
   commit message for a commit that must start the transport workflow.
4. Wait for the actual transport workflow and verify its pushed child E0.
   Assembly checks remote HEAD still equals T and pushes only a fast-forward.
   Do not advance the branch during assembly. An assembly success certifies
   bytes only; no economic or author-package CI success follows from it.
5. From exact E0 native tree, create the complete final manifest. Include
   all native regular files, transport REQUESTs, parts and receipts. Exclude
   exactly `EVIDENCE_MANIFEST121.json` and `SOURCE_READY121.json`.
6. Publish only the final manifest/marker changes at actual S through the
   plugin so the marker path triggers the author workflow. S must not carry
   a skip-CI message. It has no self-embedded S SHA; actual CI derives S from
   Git and GITHUB_SHA.

The formal source command executed by Actions is:

```bash
python verification121/ci121.py --output ci121/source
```

Only its actual successful `passed_final_author_source_package` result supports
the full final-source validation statement. On a PDF mismatch, the actual
comparison, build versions and logs are retained for investigation; hashes
must not be relabeled as matching.
