"""Tiny in-memory HTTP/ZIP fixtures; no real network or scientific data."""
import argparse
import copy
from email.message import Message
import importlib.util
import io
import json
from pathlib import Path
import time
import zipfile

HELPER = Path('/workspace/scratch/913249553838/NBO/revisions/2026-10-20-r121/verification121/remote_verify121.py')
OUT = Path('/workspace/scratch/913249553838/audit121/experiments/remote_verifier_synthetic_attempt01')
OUT.mkdir(exist_ok=False)
start = time.perf_counter()
spec = importlib.util.spec_from_file_location('remote_verify121_fixture', HELPER)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
S, P, V = '1'*40, '2'*40, '3'*40
sid = dict(commit=S, repository_tree_sha='4'*40, native_revision_tree_sha='5'*40, repository_revision_path=m.PREFIX)
pid = dict(commit=P, repository_tree_sha='6'*40, native_revision_tree_sha='7'*40, repository_revision_path=m.PREFIX)


def encode(obj):
    return (json.dumps(obj, sort_keys=True, separators=(',', ':'))+'\n').encode()


def row(name, raw):
    return dict(path=name, git_mode='100644', **m.bytes_identity(raw))


source = {f'build/{doc}.pdf': f'Synthetic bytes for {doc}.\n'.encode() for doc in m.DOCS}
source_rows = [row(name, raw) for name, raw in sorted(source.items())]
inventory = dict(schema='NBO_R121_AUTHOR_SOURCE_INVENTORY_V1', author_source_commit=S, **sid,
    files=source_rows, native_files=len(source_rows), native_bytes=sum(len(raw) for raw in source.values()))
inventory_raw = encode(inventory)
binding = dict(schema='NBO_R121_SOURCE_PDF_BINDING_V1', author_source_commit=S, **sid,
    native_files=inventory['native_files'], native_bytes=inventory['native_bytes'],
    source_inventory=dict(path=m.INVENTORY, **m.bytes_identity(inventory_raw)),
    required_publication_inputs=source_rows, pdfs=source_rows)
binding_raw = encode(binding)
members = dict(source)
members[m.INVENTORY], members[m.SPM] = inventory_raw, binding_raw
archive_buffer = io.BytesIO()
with zipfile.ZipFile(archive_buffer, 'w', compression=zipfile.ZIP_STORED) as zipped:
    for name, raw in sorted(members.items()):
        info = zipfile.ZipInfo(name, m.ZIP_DATE)
        info.create_system = 3
        info.external_attr = 0o100644 << 16
        zipped.writestr(info, raw)
archive = archive_buffer.getvalue()
assert len(archive) <= 10*1024, len(archive)
archive_identity = m.bytes_identity(archive)
manifest = dict(schema='NBO_R121_REFEREE_READY_PACKAGE_V1', archive=m.ARCHIVE, **archive_identity,
    author_source_commit=S, publication_commit=P, author_source_identity=sid, publication_identity=pid,
    source_tree_verified_members=len(source_rows), publication_native_members=len(members),
    publication_added_members=len(members)-len(source_rows),
    members=[row(name, raw) for name, raw in sorted(members.items())],
    parts=[], split_performed=False, part_size=m.PART_BYTES,
    source_inventory=dict(path=m.INVENTORY, **m.bytes_identity(inventory_raw)),
    source_pdf_manifest=dict(path=m.SPM, **m.bytes_identity(binding_raw)), pdfs=source_rows,
    root_selected_required_paths=[], complete_member_readback=dict(verified_members=len(members),
        verified_uncompressed_bytes=sum(len(raw) for raw in members.values())))
manifest_raw = encode(manifest)
descriptor = dict(schema='NBO_R121_VIRTUAL_ZIP_CHUNKS_V1', archive=m.ARCHIVE, **archive_identity,
    package_manifest=dict(path=m.PACKAGE, **m.bytes_identity(manifest_raw)), author_source_commit=S,
    publication_commit=P, future_prefix='', chunk_size=m.PART_BYTES,
    chunks=[dict(path=m.ARCHIVE+'.part0000', offset=0, **archive_identity)],
    virtual_descriptor_only=True, physical_chunk_files_written=0,
    remote_upload_attempted=False, remote_Git_object_existence_verified=False)
descriptor_raw = encode(descriptor)
payloads = {m.PACKAGE: manifest_raw, m.DESCRIPTOR: descriptor_raw, m.ARCHIVE+'.part0000': archive}
prefix = 'http://127.0.0.1:9121/Fixture/Repository/'+V+'/'+m.PREFIX+'/'
calls = []


class Response(io.BytesIO):
    def __init__(self, request, payload):
        super().__init__(payload)
        self.status = 206 if request.get_header('Range') else 200
        self.headers = Message()
        self.headers['Content-Length'] = str(len(payload))
        if self.status == 206:
            self.headers['Content-Range'] = f'bytes 0-{len(payload)-1}/{len(payload)}'
        self.url = request.full_url
    def geturl(self):
        return self.url


class Opener:
    def open(self, request, timeout):
        assert request.full_url.startswith(prefix), request.full_url
        name = request.full_url[len(prefix):]
        calls.append(dict(url=request.full_url, range=request.get_header('Range'), timeout=timeout))
        return Response(request, payloads[name])


m.urllib.request.build_opener = lambda *args: Opener()


def args(name):
    return argparse.Namespace(repository='Fixture/Repository', delivery_commit=V, source_commit=S,
        publication_commit=P, expected_manifest_sha256=m.bytes_identity(manifest_raw)['sha256'],
        expected_descriptor_sha256=m.bytes_identity(descriptor_raw)['sha256'], cache_mib=8,
        timeout_seconds=30, output_dir=OUT/name, synthetic_local_base_url='http://127.0.0.1:9121',
        allow_synthetic_local_http=True)


checks = []
m.run(args('full-valid'))
actual = json.loads((OUT/'full-valid/REMOTE_VERIFICATION121.json').read_text())
assert actual['status'] == 'passed_synthetic_transport_fixture'
assert actual['verified_members'] == len(members)
assert actual['peak_cached_part_bytes'] == len(archive) <= m.CACHE_LIMIT
assert actual['archive'] == archive_identity
assert not any(path.suffix == '.zip' for path in (OUT/'full-valid').iterdir())
checks.append('Bounded full remote pipeline accepts no-split manifest plus virtual descriptor, checks all members/S/P, and writes no archive.')
assert any(call['range'] == f'bytes=0-{len(archive)-1}' for call in calls)
checks.append('Actual request interface requests an exact whole-part HTTP range and validates 206 coverage.')
wrong = args('wrong-manifest')
wrong.expected_manifest_sha256 = '0'*64
try:
    m.run(wrong)
    raise AssertionError('Wrong observed manifest digest was accepted')
except ValueError:
    pass
assert (OUT/'wrong-manifest/FAILURE_REMOTE_VERIFICATION121.json').exists()
checks.append('Wrong caller-observed manifest digest fails before archive requests, with retained failure receipt.')
payloads[m.ARCHIVE+'.part0000'] = bytes([archive[0]^1])+archive[1:]
try:
    m.run(args('corrupted-part'))
    raise AssertionError('Corrupted part was accepted')
except ValueError:
    pass
payloads[m.ARCHIVE+'.part0000'] = archive
assert (OUT/'corrupted-part/FAILURE_REMOTE_VERIFICATION121.json').exists()
checks.append('A same-size corrupted remote part is rejected by its content identity, with HTTP and failure logs retained.')
wrong = args('wrong-source')
wrong.source_commit = 'a'*40
try:
    m.run(wrong)
    raise AssertionError('Wrong source S was accepted')
except ValueError:
    pass
checks.append('Caller-selected S mismatch is rejected without substituting embedded source identity.')
bad = copy.deepcopy(descriptor)
bad['chunks'][0]['offset'] = 1
try:
    m.validate_metadata(manifest, bad, m.bytes_identity(manifest_raw), args('not-executed'))
    raise AssertionError('Nonzero first virtual offset was accepted')
except ValueError:
    pass
checks.append('Virtual ranges require exact gap-free ordering and cover.')


class TinyTransport:
    def __init__(self):
        self.values = {'a': b'abcd', 'b': b'efg', 'c': b'hijk'}
        self.requests = 0
    def fetch(self, name, expected, limit, purpose):
        self.requests += 1
        m.match(m.bytes_identity(self.values[name]), expected, name)
        return self.values[name]


tiny = TinyTransport()
chunks = [dict(path=name, **m.bytes_identity(value)) for name, value in tiny.values.items()]
reader = m.RemoteParts(tiny, chunks, 7)
assert reader.read(5) == b'abcde'
reader.seek(2)
assert reader.read(7) == b'cdefghi'
reader.seek(0)
assert reader.read(11) == b'abcdefghijk'
assert reader.peak_cache_bytes <= 7 and tiny.requests > 3
reader.seek(100)
assert reader.read() == b''
reader.seek(0)
reader.size = m.READ_LIMIT+1
try:
    reader.read()
    raise AssertionError('Unbounded whole-archive read was accepted')
except ValueError:
    pass
reader.close()
checks.append('Tiny multi-part seek/read fixture forces LRU eviction, preserves cross-boundary bytes, and rejects an unbounded archive read.')
blocked = args('not-executed-transport')
blocked.synthetic_local_base_url = 'http://example.invalid'
try:
    m.Transport(blocked, OUT)
    raise AssertionError('Non-loopback synthetic override was accepted')
except ValueError:
    pass
checks.append('Synthetic URL override cannot target a non-loopback host.')
result = dict(status='passed_bounded_synthetic_remote_verifier_checks', checks=checks,
    archive_fixture_bytes=len(archive), helper_sha256=m.bytes_identity(HELPER.read_bytes())['sha256'],
    elapsed_seconds=time.perf_counter()-start, actual_network_connections=0,
    scientific_data_read=False, scientific_execution=False, original_repository_git_mutation=False,
    synthetic_HTTP_opener_only=True, all_failed_prefixes_retained=True)
(OUT/'RESULT121.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, sort_keys=True))
