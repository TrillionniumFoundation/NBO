"""Pure exact price-domain/format/custody diagnostics; no economic experiment."""
from fractions import Fraction as F
from pathlib import Path
import gzip,hashlib,importlib.util,json,sys,time,traceback

ROOT=Path('/workspace/scratch/913249553838')
SOURCE=ROOT/'NBO/revisions/2026-10-20-r121/code121/report121.py'
OUT=ROOT/'audit121/experiments/reporting_synthetic_attempt01'


def write(name,value):
    with (OUT/name).open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')


def main():
    OUT.mkdir(parents=True,exist_ok=False);started=time.time();checks=0
    source_hash=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    write('START.json',{'kind':'synthetic reporting algebra and serialization only','source_sha256':source_hash,
        'started_unix':started,'economic_model_imports':False,'scientific_evaluations':0})
    try:
        spec=importlib.util.spec_from_file_location('r121_report_synthetic_only',SOURCE)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        def member(domain,p):
            if domain['empty']:return False
            if p<domain['lower'] or (p==domain['lower'] and not domain['lower_closed']):return False
            if domain['upper'] is not None and (p>domain['upper'] or (p==domain['upper'] and not domain['upper_closed'])):return False
            return True
        domains=[]
        for gain in map(F,(-2,-1,0,1,2)):
            for cost in map(F,(-2,-1,0,1,2)):
                d=module.positive_domain(gain,cost);domains.append(d)
                prices=[F(0),F(1,4),F(1,2),F(1),F(2),F(4)]
                if cost and gain/cost>=0:prices+=[gain/cost]
                for p in prices:
                    assert member(d,p)==(gain-p*cost>0);checks+=1
                module.domain_tex(d)
        for a in domains:
            for b in domains:
                d=module.intersect_domains(a,b)
                for p in (F(0),F(1,4),F(1,2),F(1),F(2),F(4)):
                    assert member(d,p)==(member(a,p) and member(b,p));checks+=1
        for value in (F(1,3),F(-1,3),F(1,10**30),F(-1,10**30),F(1001,200),F(-1001,200)):
            for digits in (0,2,7):
                assert F(module.fixed(value,digits,'down'))<=value<=F(module.fixed(value,digits,'up'));checks+=1
        assert module.fixed(F(1,200),2)=='0.00';assert module.fixed(F(3,200),2)=='0.02';checks+=2
        assert module.fixed(F(-3,200),2)=='-0.02';checks+=1
        values=[{'case':'synthetic-only','value':F(1,3),'nested':[F(-1,7),True,None]}]
        for sub in ('one','two'):
            output=module.Outputs(OUT/sub);output.rows('rows.jsonl.gz',values,True);output.csv('rows.csv.gz',values,True)
        hashes={}
        for name in ('rows.jsonl.gz','rows.csv.gz'):
            a=(OUT/'one'/name).read_bytes();b=(OUT/'two'/name).read_bytes();assert a==b;checks+=1
            gzip.decompress(a);hashes[name]=hashlib.sha256(a).hexdigest()
        assert not {'numpy','scipy','investment94','continuum94','kernel108','models121','labels121','exact121'}.intersection(sys.modules);checks+=1
        assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==source_hash;checks+=1
        result={'status':'executed','exit_code':0,'checks':checks,'elapsed_seconds':time.time()-started,
            'source_sha256':source_hash,'serialization_hashes':hashes,'scientific_evaluations':0,
            'fitting_invocations':0,'state_draws':0,'timing_campaigns':0,'original_model_data_read':False}
        write('RESULT.json',result);print(json.dumps(result,sort_keys=True))
    except BaseException:
        write('FAILED.json',{'status':'failed','checks':checks,'elapsed_seconds':time.time()-started,'traceback':traceback.format_exc()});raise


if __name__=='__main__':main()
