# R121 completed-data reporting interface

This is postprocessing source under the already fixed `REPORTING_SPEC121.md`.
It is deposited with final author source S; it is not misdated as experimental
source F. No full report has been run at this readiness stage, and no R121
economic result is claimed here.

## Sources and dependencies

- `code121/report121.py`: standard library only; SHA256
  `e622c382e0ae184aac6ef366bdd2acc0fb2c7cd8cc3ed4f3c1845eba8c77f287`.
- `verification121/study_integrity121.py`: imports only that postprocessing
  module; SHA256
  `c9009a5e04f74b9d51cd58bbb1a08dd147239538ae6d08cdbc0200d31bb790a6`.
- Local Git trees for the actual F, M and D are needed for immutable source and
  artifact byte checks. No network operation, Git mutation or scientific import
  occurs in reporting.

## Invocation after every actual input stage completes

The root owner supplies actual full commits and exact completed directories:

```sh
python code121/report121.py \
  --revision /absolute/native/revisions/2026-10-20-r121 \
  --repository /absolute/native/repository \
  --evidence-root /absolute/native/or/isolated/extracted/revision \
  --source-commit FULL_F --actor-commit FULL_M --state-commit FULL_D \
  --acquisition5 results121/acquisition5-attempt01 \
  --acquisition9 results121/acquisition9-attempt01 \
  --training-audit5 results121/training-audit5-attempt01 \
  --training-audit9 results121/training-audit9-attempt01 \
  --states results121/states-attempt01 \
  --primary results121/primary-attempt01 \
  --independent results121/independent-attempt01 \
  --stats results121/stats-attempt01 \
  --ledger-root results121 \
  --output /absolute/fresh/reporting-attempt01
```

The directory flags are explicit remappable inputs. The names above are
defaults, not assertions that those attempts exist. `--ledger-root` must cover
the actual completed `LAUNCH121.json`/stdout receipts for the two acquisitions,
two training audits, primary process, independent evaluation and statistics.
It can instead be a wider evidence-relative directory if the root launcher
receipts are stored elsewhere. The current report's eventual outer launcher
receipt is excluded by command identity; it is not a mutable self-input.

The integrity entry has the same arguments and appends `--integrity-only`.
It verifies immutable bytes, all censuses, saved-record arithmetic and complete
cost decomposition without producing the study tables. Neither mode imports
an economic evaluator, training solver or the frozen statistics program.

## Mandatory read-only gates

- Source F, all complete acquisition manifests and 56 actors at M, all 640
  entropy bytes and 64 retained observation rows at D, and F→M→D ancestry.
- Exact 3,712 primary identities and original-service qualification, every raw
  proposal including nullable numerical failures, all independent key matches,
  original objective arithmetic and compatibility-only interval overlap.
- All 58 batches for primary and each of five timing processes, full counts,
  actual primitive-trace byte hashes and 9,280 saved action/state/qualification
  identities against primary.
- All 56 model audits and their witness files; stats input bytes; exact unique
  58 policy, 28 treatment, two optimal-value and four signed-event-per-treatment
  censuses. All 88 mean intervals, 112 threshold and 116 rejection endpoints
  are checked with fixed rational radii and exact saved binomial inequalities.
- Exact component accounting from nonoverlapping recorded phases. Nested
  timing child processes are subtracted once when isolating primary cost and
  are not added twice to the whole research ledger.

## Products and replay

The fresh output creates `tables121/`, `new121/results121.tex`,
`new121/development121_results.tex`, `SUMMARY_REPORT121.json`, and
`OUTPUT_MANIFEST121.json`. Its actual `stable_replay_files` list is authoritative
for byte-identical replay; the designed full report has 49 such products.

All 58 cells, 28 signed learning contrasts, 28 budget contrasts, 812 unordered
full-menu pairs for each 64/32-state cohort, 348 clocks, 1,392 volume-cost and
frontier rows, all pairwise price constraints, 2,832 menu conditions and 472
five-clock intersections are retained. Model/certificate counters, every
qualification attempt, actor trace and exact equality control are included.
Gzip products use empty header names and `mtime=0`; exact rationals are serialized
as numerator/denominator strings.

Actual starts, input locations/metadata, execution clocks, research/support
ledger and the output manifest are distinct custody products, explicitly
excluded from table byte equality. Every partial failed reporting attempt is
retained in its exclusive directory. There is no automatic economic rerun,
retiming or substitution.

The deployment formula includes actual labels, own fit/storage, required
training audit, explicitly allocated common process residual, cold load,
production certificate, refusals and fallback. Hinge pays the corresponding
parent ReLU fit/audit plus its own work. Independent all-policy evaluation is
separately included in the whole research ledger and excluded from the declared
deployment-reuse formula. Failed or unrelated support processes remain explicit
in that ledger; they are not silently represented as a successful standalone
method's measured components.
