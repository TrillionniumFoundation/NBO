# Proposed R121 final-author CI gates (notes only)

These are implementation notes for the root agent, not an executed workflow or a CI success claim. Scientific F is `16bf21334efcbc719b83e2ccf10e8527f8b956f2`. Actual M, D and final author S must be supplied from their completed remote boundaries.

## Source and custody

Use the R120 pinned checkout, Python and upload-artifact actions; trigger only the new R121 isolated branch and native R121/workflow paths. `contents: read`, credentials not persisted, Python 3.12.14 and existing pinned requirements remain appropriate. Checkout complete ancestor metadata (`fetch-depth: 0`, `filter: blob:none`) and only the R121 native path plus workflows. F/M/D must be present locally before Git-byte checking; `git ls-tree` binds actual evidence files without reevaluating the economy.

Require the checked-out commit to equal the actual final author S for the source CI run. Verify the complete final evidence manifest and every retained success/failure file hash before any replay. Verify F's source manifest and all 169 scientific files; actor manifests and every acquired model/label/fit at M; exact 640-byte states and every D member; distinct F -> M -> D -> S ancestry. Preserve the declared separate R98/R115 constraints and historical source mappings.

## Saved-record gate

Run `verification121/study_integrity121.py --source-commit F --actor-commit M --state-commit D --output ci121/integrity`. Its default evidence inputs are the eight completed results121 attempt01 directories; a changed actual attempt path must be passed explicitly, never renamed as attempt01. It checks all actual source/artifact bytes, all 56 actors, 3,712 primary rows, 9,280 timing action identities, exact independent policy/first-proposal coverage, unchanged original qualification thresholds, every rejection attempt, all 88 saved means and all 228 saved event/rejection probability endpoints, and complete cost decomposition. It does not import the economy, fitter or independent evaluator.

This gate is a source/record/interval-arithmetic audit, not a rerun of independent original-economic acquisition or scientific inference. The actual independent rational experiment remains its separately source-bound completed launch and witness files.

## Deterministic replay

Execute frozen `stats121.py` on the identical original saved primary and independent-comparison bytes into a new `ci121/statistics-replay` directory. Compare the three scientific JSONL tables byte-for-byte with their original counterparts; its execution timestamps and paths are declared custody outputs and are not stable table bytes.

Execute `code121/report121.py --source-commit F --actor-commit M --state-commit D --output ci121/reporting-replay`. Compare every path and SHA in the original report's `OUTPUT_MANIFEST121.json.stable_replay_files`; require exact equality of the file set as well as bytes, not merely selected favorable tables. The original report output includes exact rational tables, deterministic gzip, `new121/results121.tex`, `new121/development121_results.tex` and TABLE_SCOPE121.md. START_REPORT121, INPUTS_REPORT121, EXECUTION_REPORT121, RESEARCH_LEDGER121 and output manifest are declared runtime/custody products; retain them without claiming byte identity. Do not put CI replay launch receipts into the original results121 scientific ledger, which would change its discovered support-run population.

Report code is deposited at S under the F-frozen reporting specification; do not relabel the reporter itself as frozen at F.

## Documents and actual evidence

Run the strict four-document `build121.py` command with the native ECTA/supp/appendix/RESPONSE wrappers, deterministic source epoch and complete input closure. A diagnostic or partial build is not the required gate. Retain every process exit code and complete TeX logs; reject unresolved citations/references or material overfull boxes according to the actual strict builder. Compare actual CI PDFs to their native S-bound PDF hashes if the deterministic same-version environment supports exact byte equality; otherwise report the exact difference honestly and investigate it before P/V.

Upload all actual audit, statistical replay, reporting replay and strict build outputs with `if: always()`, including failure files and logs. A successful Actions conclusion and downloadable artifact are distinct obligations: record the actual source SHA, run/job/artifact identities, exact response times, artifact download SHA and archive member identities. Claim CI only for the actual commit that ran, not additive later P/V packaging commits skipped by CI.

## Cost scope

Original economic acquisition, every independent audit, primary and five timing processes remain their original actual clocks. CI record checking, statistical/report replay, document building and packaging are separately measured support work; never replace scientific clocks with CI replay duration. Timing subprocess clocks are already inside the actual primary outer process and must not be added twice. All method allocations differ explicitly from observed full-study process totals.
