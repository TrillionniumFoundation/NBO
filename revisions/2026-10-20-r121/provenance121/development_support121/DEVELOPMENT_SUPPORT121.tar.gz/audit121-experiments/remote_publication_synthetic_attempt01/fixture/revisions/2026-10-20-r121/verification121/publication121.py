"""Synthetic publication CLI stub used only in an isolated fixture."""
import argparse, hashlib, io, json
from pathlib import Path
import zipfile

def ident(raw):
 return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest())
def emit(root,name,obj):
 (root/name).write_text(json.dumps(obj,sort_keys=True,indent=2)+'\n')
p=argparse.ArgumentParser();p.add_argument('mode');p.add_argument('--revision');p.add_argument('--source-commit');p.add_argument('--publication-commit');p.add_argument('--no-split',action='store_true');p.add_argument('--required-path',action='append');p.add_argument('--manifest',type=Path);p.add_argument('--archive',type=Path);p.add_argument('--expected-manifest-sha256');p.add_argument('--output-dir',type=Path,required=True)
a=p.parse_args();a.output_dir.mkdir()
emit(a.output_dir,'START121.json',dict(scope='synthetic CLI interface only',mode=a.mode))
archive='referee-ready121.zip';package='REFEREE_READY_PACKAGE121.json'
if a.mode=='pack':
 assert a.no_split and len(a.required_path)==2
 buffer=io.BytesIO()
 with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_STORED) as zipped:
  zipped.writestr('synthetic.txt',b'Tiny infrastructure fixture; no scientific claim.\n')
 raw=buffer.getvalue();(a.output_dir/archive).write_bytes(raw)
 emit(a.output_dir,package,dict(schema='NBO_R121_REFEREE_READY_PACKAGE_V1',archive=archive,**ident(raw),author_source_commit=a.source_commit,publication_commit=a.publication_commit,split_performed=False,parts=[]))
elif a.mode=='verify':
 raw=a.archive.read_bytes();manifest=json.loads(a.manifest.read_text())
 assert ident(raw)['sha256']==manifest['sha256']
 assert ident(a.manifest.read_bytes())['sha256']==a.expected_manifest_sha256
 with zipfile.ZipFile(io.BytesIO(raw)) as zipped: assert zipped.read('synthetic.txt').startswith(b'Tiny infrastructure')
elif a.mode=='describe-parts':
 raw=a.archive.read_bytes();manifest=json.loads(a.manifest.read_text())
 emit(a.output_dir,'VIRTUAL_ZIP_CHUNKS121.json',dict(schema='NBO_R121_VIRTUAL_ZIP_CHUNKS_V1',archive=archive,**ident(raw),author_source_commit=manifest['author_source_commit'],publication_commit=manifest['publication_commit'],future_prefix='',chunk_size=8<<20,physical_chunk_files_written=0,package_manifest=dict(path=package,**ident(a.manifest.read_bytes())),chunks=[dict(path=archive+'.part0000',offset=0,**ident(raw))]))
else: raise ValueError(a.mode)
emit(a.output_dir,'PUBLICATION_ATTEMPT121.json',dict(status='synthetic_interface_passed',mode=a.mode,scientific_execution=False))
