# Synthetic byte fixture; never imported or executed.
