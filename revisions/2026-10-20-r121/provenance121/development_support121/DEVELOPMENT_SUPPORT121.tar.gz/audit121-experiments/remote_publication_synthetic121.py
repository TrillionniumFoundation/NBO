"""Small orchestration fixture; no real GitHub, scientific files or package.

The publication subprocess is an explicitly synthetic interface stub. The
publisher's unchanged source performs its real Git identity, additive-index,
part-object, artifact-order and local-bare fast-forward operations. Strict
scientific/source build/package validity is outside this fixture's scope.
"""
from pathlib import Path
from types import SimpleNamespace
import ast
import contextlib
import datetime
import hashlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
BASE = Path('/workspace/scratch/913249553838')
REAL = BASE / 'NBO'
NATIVE = REAL / 'revisions/2026-10-20-r121'
OUT = BASE / 'audit121/experiments/remote_publication_synthetic_attempt01'
OUT.mkdir()
REPO = OUT / 'fixture'
REPO.mkdir()
PREFIX = 'revisions/2026-10-20-r121'
ROOT = REPO / PREFIX
ROOT.mkdir(parents=True)
BARE = OUT / 'synthetic-origin.git'
commands = []
checks = []
started = time.perf_counter()
environment = dict(os.environ, GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
    GIT_AUTHOR_NAME='Synthetic Fixture', GIT_AUTHOR_EMAIL='fixture@example.invalid',
    GIT_COMMITTER_NAME='Synthetic Fixture', GIT_COMMITTER_EMAIL='fixture@example.invalid',
    PYTHONDONTWRITEBYTECODE='1')


def git(*args, cwd=REPO):
    result = subprocess.run(['git', *args], cwd=cwd, env=environment, capture_output=True)
    row = dict(argv=['git', *args], cwd=str(cwd), exit_code=result.returncode,
        stdout=result.stdout.decode('utf-8', errors='replace'), stderr=result.stderr.decode('utf-8', errors='replace'))
    commands.append(row)
    if result.returncode:
        raise RuntimeError(row)
    return result.stdout


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data if isinstance(data, bytes) else (json.dumps(data, sort_keys=True, indent=2)+'\n').encode())


source = NATIVE / 'verification121/remote_publish121.py'
source_bytes = source.read_bytes()
ast.parse(source_bytes)
spec = importlib.util.spec_from_file_location('publisher_fixture121', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

stub = r'''"""Synthetic publication CLI stub used only in an isolated fixture."""
import argparse, hashlib, io, json
from pathlib import Path
import zipfile

def ident(raw):
 return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest())
def emit(root,name,obj):
 (root/name).write_text(json.dumps(obj,sort_keys=True,indent=2)+'\n')
p=argparse.ArgumentParser();p.add_argument('mode');p.add_argument('--revision');p.add_argument('--source-commit');p.add_argument('--publication-commit');p.add_argument('--no-split',action='store_true');p.add_argument('--required-path',action='append');p.add_argument('--manifest',type=Path);p.add_argument('--archive',type=Path);p.add_argument('--expected-manifest-sha256');p.add_argument('--output-dir',type=Path,required=True)
a=p.parse_args();a.output_dir.mkdir()
emit(a.output_dir,'START121.json',dict(scope='synthetic CLI interface only',mode=a.mode))
archive='referee-ready121.zip';package='REFEREE_READY_PACKAGE121.json'
if a.mode=='pack':
 assert a.no_split and len(a.required_path)==2
 buffer=io.BytesIO()
 with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_STORED) as zipped:
  zipped.writestr('synthetic.txt',b'Tiny infrastructure fixture; no scientific claim.\n')
 raw=buffer.getvalue();(a.output_dir/archive).write_bytes(raw)
 emit(a.output_dir,package,dict(schema='NBO_R121_REFEREE_READY_PACKAGE_V1',archive=archive,**ident(raw),author_source_commit=a.source_commit,publication_commit=a.publication_commit,split_performed=False,parts=[]))
elif a.mode=='verify':
 raw=a.archive.read_bytes();manifest=json.loads(a.manifest.read_text())
 assert ident(raw)['sha256']==manifest['sha256']
 assert ident(a.manifest.read_bytes())['sha256']==a.expected_manifest_sha256
 with zipfile.ZipFile(io.BytesIO(raw)) as zipped: assert zipped.read('synthetic.txt').startswith(b'Tiny infrastructure')
elif a.mode=='describe-parts':
 raw=a.archive.read_bytes();manifest=json.loads(a.manifest.read_text())
 emit(a.output_dir,'VIRTUAL_ZIP_CHUNKS121.json',dict(schema='NBO_R121_VIRTUAL_ZIP_CHUNKS_V1',archive=archive,**ident(raw),author_source_commit=manifest['author_source_commit'],publication_commit=manifest['publication_commit'],future_prefix='',chunk_size=8<<20,physical_chunk_files_written=0,package_manifest=dict(path=package,**ident(a.manifest.read_bytes())),chunks=[dict(path=archive+'.part0000',offset=0,**ident(raw))]))
else: raise ValueError(a.mode)
emit(a.output_dir,'PUBLICATION_ATTEMPT121.json',dict(status='synthetic_interface_passed',mode=a.mode,scientific_execution=False))
'''

for name in ('verification121/remote_publish121.py', 'verification121/remote_verify121.py'):
    write(ROOT/name, (NATIVE/name).read_bytes())
write(ROOT/'verification121/publication121.py', stub.encode())
for name in (module.WORKFLOW, module.CI_WORKFLOW):
    write(REPO/name, (REAL/name).read_bytes())
write(ROOT/'SYNTHETIC_FIXTURE_ONLY.json', {'scientific_data':False, 'actual_GitHub_API':False})
git('init', '-b', module.BRANCH)
git('add', '.')
git('commit', '-m', 'Synthetic source S only')
S = git('rev-parse', 'HEAD').decode().strip()
ci_name, readback_name = 'ci/CI_RESULT121.json', 'ci/REMOTE_READBACK121.json'
write(ROOT/ci_name, dict(status='passed_final_author_source_package', exit_code=0,
    checked_out_commit=S, final_author_source_ci=True, complete_author_package_gate=True,
    strict_build_and_all_four_pdf_hashes_verified=True, original_economic_execution_performed=False,
    synthetic_fixture_record=True))
write(ROOT/readback_name, dict(source_commit=S, head_sha=S, run_id=101, status='completed',
    conclusion='success', workflow_path=module.CI_WORKFLOW, synthetic_fixture_record=True))
git('add', '.')
git('commit', '-m', 'Synthetic publication P only')
P = git('rev-parse', 'HEAD').decode().strip()
request = dict(kind='nbo-r121-remote-publication-request-v1', revision_prefix=PREFIX,
    author_source_commit=S, publication_commit=P, source_ci_run_id=101,
    required_records=dict(author_source_ci_result=ci_name, author_source_ci_remote_readback=readback_name),
    required_publication_paths=[])
write(ROOT/module.REQUEST_NATIVE, request)
git('add', '.')
git('commit', '-m', 'Synthetic exact Q request only')
Q = git('rev-parse', 'HEAD').decode().strip()
git('init', '--bare', str(BARE))
git('remote', 'add', 'origin', str(BARE))
git('push', 'origin', 'HEAD:refs/heads/'+module.BRANCH)
os.environ.update(environment)
os.environ.update(GITHUB_RUN_ID='202', GITHUB_RUN_ATTEMPT='2', GITHUB_REPOSITORY=module.REPOSITORY,
    GITHUB_REF='refs/heads/'+module.BRANCH, GITHUB_SHA=Q)
metadata_calls = []
bad_ci = False
bad_artifact = False


def metadata(job, route, label):
    metadata_calls.append(dict(route=route,label=label,synthetic_response=True))
    if label=='source-ci-api':
        response = dict(id=101, head_sha='0'*40 if bad_ci else S, status='completed', conclusion='success',
            path=module.CI_WORKFLOW, head_branch=module.BRANCH)
    elif label=='uploaded-artifact-api':
        response = dict(id=303, name='nbo-r121-referee-ready-'+Q+'-attempt2', expired=False,
            workflow_run=dict(id=202,head_sha=Q), digest='sha256:'+('b'*64 if bad_artifact else 'a'*64),
            size_in_bytes=999, synthetic_metadata=True)
    else:
        raise AssertionError('Unexpected fixture API route '+route)
    module.save(job.work/(label+'.json'),dict(synthetic_response=True,response=response))
    return response


module.Job.metadata = metadata


def job(phase, path, q=Q):
    os.environ['GITHUB_SHA'] = q
    return module.Job(SimpleNamespace(phase=phase,repository=REPO,work_dir=path,request_commit=q,
        artifact_id='303',artifact_digest='a'*64,
        artifact_url='https://github.com/'+module.REPOSITORY+'/actions/runs/202/artifacts/303'))


def rejection(label, action, job_instance):
    try:
        action()
    except ValueError as error:
        job_instance.failure()
        checks.append(dict(check=label,status='passed',actual_error=str(error)))
    else:
        raise AssertionError('Invalid fixture accepted: '+label)


try:
    # Construct a separate invalid child of P, retaining its actual commit.
    git('checkout', '--detach', P)
    write(ROOT/module.REQUEST_NATIVE, request)
    write(ROOT/'unexpected.txt', b'Unauthorized extra Q addition.\n')
    git('add', '.')
    git('commit', '-m', 'Synthetic invalid Q with two additions')
    bad_q = git('rev-parse', 'HEAD').decode().strip()
    bad = job('prepare', OUT/'bad-q', bad_q)
    rejection('Q_with_extra_added_path_rejected_before_pack',lambda:module.prepare(bad),bad)
    git('checkout', module.BRANCH)
    os.environ['GITHUB_SHA']=Q
    bad_ci=True
    bad=job('prepare',OUT/'bad-ci')
    rejection('actual_source_CI_wrong_S_rejected_before_pack',lambda:module.prepare(bad),bad)
    bad_ci=False
    with (OUT/'prepare.stdout.log').open('w') as captured, contextlib.redirect_stdout(captured):
        prepared=job('prepare',OUT/'work')
        module.prepare(prepared)
    checks.append(dict(check='prepare_checks_actual_Q_and_invokes_pack_verify_describe_interfaces',status='passed'))
    shutil.copytree(OUT/'work',OUT/'bad-artifact')
    bad_artifact=True
    bad=job('finalize',OUT/'bad-artifact')
    rejection('artifact_digest_mismatch_rejected_before_any_Git_object_write',lambda:module.finalize(bad),bad)
    assert not any('hash-object' in row['argv'] for row in bad.commands)
    assert not git('diff','--cached','--name-only')
    bad_artifact=False
    with (OUT/'finalize.stdout.log').open('w') as captured, contextlib.redirect_stdout(captured):
        finished=job('finalize',OUT/'work')
        module.finalize(finished)
    V=git('rev-parse','HEAD').decode().strip()
    assert git('rev-parse','HEAD^').decode().strip()==Q
    assert git('ls-remote','origin','refs/heads/'+module.BRANCH).decode().split()[0]==V
    checks.append(dict(check='actual_additive_V_has_Q_parent_and_fast_forwards_local_bare_origin',status='passed'))
    archive=(OUT/'work/pack'/module.ARCHIVE).read_bytes()
    part=PREFIX+'/'+module.ARCHIVE+'.part0000'
    assert git('show',V+':'+part)==archive
    assert not (ROOT/(module.ARCHIVE+'.part0000')).exists()
    assert git('ls-tree','-r','--name-only',V,'--',PREFIX+'/'+module.ARCHIVE)==b''
    checks.append(dict(check='part_Git_blob_exact_archive_bytes_without_physical_part_or_full_ZIP_Git_file',status='passed'))
    change=git('diff','--name-status',Q,V).decode().splitlines()
    assert all(row.startswith('A\t'+PREFIX+'/') for row in change)
    assert git('diff',P,V,'--',PREFIX+'/verification121',module.WORKFLOW,module.CI_WORKFLOW)==b''
    checks.append(dict(check='existing_source_and_P_Q_files_preserved_with_only_additive_delivery',status='passed'))
    receipt=json.loads(git('show',V+':'+PREFIX+'/delivery121/receipts/DELIVERY_PRECOMMIT121.json'))
    assert receipt['commit_and_remote_push_completed_at_receipt_creation'] is False
    assert receipt['artifact']['action_output_digest_sha256']=='a'*64
    assert receipt['context']['actual_workflow_run_attempt']=='2'
    assert any('/logs/finalize-' in row for row in change)
    assert json.loads((OUT/'work/PUSH_RESULT121.json').read_text())['delivery_commit']==V
    checks.append(dict(check='attempt_bound_artifact_and_finite_finalization_logs_in_V_postpush_identity_only_outside_V',status='passed'))
    bad=job('prepare',OUT/'moved-remote')
    rejection('moved_remote_Q_refused_without_force_or_overwrite',bad.compare_remote_q,bad)
    result=dict(status='passed_bounded_synthetic_remote_publication_orchestration',checks=checks,
        actual_scientific_inputs_read=False,original_science_executed=False,actual_GitHub_network_connections=0,
        original_repository_Git_mutation=False,fixture_Git_operations=True,
        publication_cli_is_explicit_synthetic_stub=True,strict_source_build_or_complete_real_package_validation_claimed=False,
        archive_bytes=len(archive),S=S,P=P,Q=Q,V=V,invalid_Q=bad_q,
        helper_sha256=hashlib.sha256(source_bytes).hexdigest(),elapsed_seconds=time.perf_counter()-started,
        metadata_calls=metadata_calls,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write(OUT/'RESULT121.json',result)
    print(json.dumps({key:result[key] for key in ('status','archive_bytes','helper_sha256','elapsed_seconds')}))
except BaseException:
    write(OUT/'FAILURE121.json',dict(status='synthetic_fixture_failed',traceback=traceback.format_exc(),
        scientific_inputs_read=False,original_science_executed=False,original_repository_Git_mutation=False))
    raise
finally:
    write(OUT/'FIXTURE_COMMANDS121.json',commands)
