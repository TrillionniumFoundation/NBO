"""Pre-freeze algebra only: synthetic features, no Bellman primitive or fit.

This script never imports labels121, investment94, a production label file or
held-out data. The manufactured coefficients are not experimental actors.
"""
from __future__ import annotations
import argparse, hashlib, json, os, sys, time, traceback
from pathlib import Path


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--revision',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=False);started=time.time()
    def record(name,value):
        with (out/name).open('x') as stream:
            json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
            stream.flush();os.fsync(stream.fileno())
    record('START.json',dict(argv=sys.argv,started_unix=started,scope='manufactured algebra, no original Bellman labels, fitted actors, held-out samples or performance comparison'))
    try:
        sys.path.insert(0,str(args.revision.resolve()/'code121'))
        import numpy as np
        import models121 as m
        counts={'piece_values':0,'actors':0,'exact_boundary_actors':0};rows=[]
        states=((0.,0.),(1.,1.),(.375,.625),(.5,.5),(0.,1.))
        for budget in (5,9):
            knots=[j/(budget-1) for j in range(budget)]
            for arm in m.ARMS:
                desc=m.definition(arm,budget)
                anchor=dict(state_knots=knots,q0_midpoints=[0.]*(budget**2))
                theta=np.array([((-1)**j)*(j%5)/16 for j in range(desc['feature_count'])])
                theta=np.maximum(theta,desc['coefficient_lower'])
                model=dict(kind='r121-anchored-root-critic',basis=desc,theta=theta.tolist(),anchor=anchor)
                for x in states:
                    breaks=m.action_breaks(desc,x)
                    largest=0.
                    for left,right in zip(breaks[:-1],breaks[1:]):
                        mid=(left+right)/2;poly=m._piece_polynomial(model,x,mid)
                        # Endpoints are included; values, not derivatives, are continuous.
                        v=np.linspace(left,right,17)
                        expected=m.critic(model,x,v,False);got=poly(v-mid)
                        error=float(np.max(np.abs(got-expected)));largest=max(largest,error)
                        assert error <= 2**-36*(1+float(np.max(np.abs(expected))))
                        counts['piece_values']+=len(v)
                    action,trace=m.actor(model,x)
                    assert 0<=action<=m.capacity(x)
                    selected=float(m.critic(model,x,[action/m.capacity(x)],False)[0])
                    dense=float(np.min(m.critic(model,x,np.linspace(0,1,1025),False)))
                    assert selected<=dense+2**-20
                    counts['actors']+=1
                    rows.append(dict(budget=budget,arm=arm,state=x,max_piece_value_error=largest,
                                     stored_action=action,synthetic_search_crosscheck=True))
                for sign in (-1,1):
                    coefficients=np.zeros(desc['feature_count'])
                    if desc['type']=='monomial':
                        coefficients[desc['exponents'].index([0,0,1])]=sign
                    elif desc['type']=='anchored_relu':coefficients[0]=sign
                    elif desc['type']=='tensor_hat':
                        for j,(_,_,k) in enumerate(desc['columns']):coefficients[j]=sign*desc['knots'][2][k]
                    else:
                        knotsv=desc['knots'][2]
                        for j,(_,_,k) in enumerate(desc['columns']):coefficients[j]=sign*sum(knotsv[k+1:k+4])/3
                    manufactured=dict(model,theta=coefficients.tolist())
                    for x in states:
                        action,trace=m.actor(manufactured,x)
                        expected=0. if sign==1 else np.floor(m.capacity(x)*2**30)/2**30
                        assert action==expected,(budget,arm,sign,x,action,expected)
                        counts['exact_boundary_actors']+=1
        assert not {'investment94','labels121','continuum94','kernel108'} & set(sys.modules)
        source=args.revision.resolve()/'code121/models121.py'
        record('RESULT.json',dict(status='passed',counts=counts,rows=rows,
            source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
            original_economy_evaluations=0,scientific_training_runs=0,random_samples=0,
            actual_elapsed_seconds=time.time()-started,
            scope='algebraic extraction and manufactured numerical actor validation only; no guarantee of exact floating root completeness'))
        print(json.dumps({'status':'passed','counts':counts,'original_economy_evaluations':0}),flush=True)
    except BaseException:
        record('FAILURE.json',dict(status='failed',exception=traceback.format_exc(),elapsed_seconds=time.time()-started))
        raise


if __name__=='__main__':main()
