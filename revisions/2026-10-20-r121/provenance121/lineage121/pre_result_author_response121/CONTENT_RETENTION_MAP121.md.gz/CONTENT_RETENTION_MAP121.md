# R121 content retention and scientific identity

## Controlling sources

This author revision continues **Neural Bellman Operators in the original recursive economic decision problem**, with Econometrica numerical methods as the intended contribution. It does not adopt the literal M1 recommendation to abandon that program or change venue. Its scientific request for a focused decision question is addressed through original-risk marginal acquisition, bounded critic fitting, feasible actor extraction, and complete economic comparison.

The reliable completed baseline is R120 author source **39a20bf1fe011175857811bf67bacd788ae80c52**, source/PDF publication **cc58ec9613044f97aa1ae5c8d60ec1c3c0021dcd**, and final delivery **f06f220aea525088e82228e8e9be4947fb81b1ca** on revision/econometrica-nbo-r120-certified-policy-improvement-2026-10-19. Its complete source, actual evidence, four PDFs and package remain immutable. The baseline is not selected by its version number: provenance121/BASELINE_R120_READBACK121.json and provenance121/BASELINE_PACKAGE_READBACK121.json bind its actual source and delivered package.

The controlling persisted advisory is still **9723c6cd2cc8b3e071422f3e522d4a843946db63**, which assesses R97 manuscript **f802fe64d91d9f5c1c8f86123b0fbe114e622279**. Its original report path is reviews/2026-10-14-econometrica-numerical-methods-r97/referee_report.md, blob **33ba8b144e2f7816b19b036404341402d23a582f**, SHA-256 **479b28c8800084846336cac078877a01dbbd2bae546d179633a2734401da19b9**. It is an owner-commissioned AI-assisted advisory, not a journal decision or a review of R119, R120 or R121.

The initial 20 October 2026 all-head observation contains **361 remote branches, 303 distinct head commits and no newer report or completed author manuscript**. The original 360 heads are unchanged; the existing R120 head has its final publication. The complete census enumerated 24,121,986 recursive tree entries and 67,440 distinct blob identities. A tree enumeration proves the file census and identities, not semantic reading, proof correctness or successful execution of every historical payload.

The later complete remote-head observation finished at **2026-10-20 18:58:57 UTC** and contains **362 branches**. The actual comparison finds **all 361 prior heads unchanged**; the sole addition is the isolated R121 branch at D, 68eae434c0e61fb1a61c3271c651c83c28619a07. The observations and delta are preserved in provenance121/REMOTE_BRANCHES121_POST_CAMPAIGN.json and provenance121/POST_CAMPAIGN_BRANCH_DELTA121.json. This refresh preserves the controlling baseline/report determination. It does not turn a new branch-head check into a new all-history scientific execution or proof validation.

## Exact original reports and response routes

| Retained object | R121 location | Scope |
|---|---|---|
| All 35 distinct original report bodies, 975,366 bytes | provenance121/reports121/REPORT_SOURCE_INDEX121.json and the 35 listed referee_report.md files | Byte-for-byte copies, each bound to its original review commit, path, Git blob and SHA-256. |
| Complete report identity and transport index | provenance121/reports121/REPORT_SOURCE_INDEX121.json | All 36 review refs; the R16 ref does not contribute a distinct report. |
| 620 major author response routes | provenance121/reports121/inherited_maps/HISTORICAL_CARRYFORWARD119.json.gz | Exact inherited compressed bytes and original source identities. |
| 394 additional request routes and 35 overlapping parent treatments | provenance121/reports121/inherited_maps/ADDITIONAL_REFEREE_RESPONSE119.json.gz | The 394 consist of 68 explicit minor, 295 supplementary and 31 embedded requests. The parent treatments overlap these and are not independent issues. |
| All 1,049 inherited item/parent bindings | provenance121/reports121/inherited_maps/HISTORICAL_ROUTE_BINDINGS120.json.gz | Lossless deterministic compression of the unchanged original R120 route map. |
| Complete prior 30-item R97 response map | provenance121/reports121/inherited_maps/R97_REQUIREMENTS120.json.gz | Lossless copy retaining every old comment, mathematical action, outcome and source binding. |
| Current exact 30-item response | new121/response121_body.tex and provenance121/R97_REQUIREMENTS121.json | Each original quotation is retained exactly; each full prior record is nested unchanged in the current machine map. Current mathematical and empirical scope is separate. |

There are 1,014 request records excluding overlapping parents, 1,049 authored item/parent routes including them, and 1,146 hierarchical source sections. These counts do **not** mean 1,049 independent issues or 1,049 closed issues. Every inherited source paragraph remains recoverable with its original identity. AUTHOR_RESPONSE_INITIAL121.json records the initial exact equality check for all 30 current quotations. The two current mathematical bindings have subsequently been matched to actual source F; final editorial and numerical source integration remains separate.

The exact initial R121 response and requirements map are also preserved under provenance121/lineage121/initial_author_response121/INDEX121.json as lossless deterministic gzip copies. Their 643,923 uncompressed bytes retain the original hashes used by the dated report-reading receipt. Later outcome integration may update the active response and map without making those earlier source bindings unresolvable.

The complete report-reading receipt distinguishes actual full-body reading from a byte or heading census. The initial response preparation had 25 confirmed full bodies; the ten early R1–R15 bodies have subsequently been read in full as well. **All 35 original report bodies now have actual full semantic reading coverage across the two named author-side AI agents**, recorded in provenance121/lineage121/REPORT_READING_COVERAGE121.json. Its exact IDs, original body hashes, readers and source-specific notes distinguish that completed report reading from a fresh reproof or rerun of the entire historical research program. The initial and corrected late numerical notes are both retained; the correction separates assessed manuscript commits from persisted report commits.

## Compact all-branch census

provenance121/lineage121/COMPACT_CENSUS_INDEX121.json binds the complete compact record:

- ALL_BRANCH_FILE_LEDGER121.json: every branch, head commit and tree; all 303 raw stream byte counts, entry counts and SHA-256 values.
- ORIGINAL_REPORT_CENSUS121.json: every original report identity and heading census.
- LINEAGE_CENSUS_RECEIPT121.json: the actual completed 92.160656-second read-only census.
- api/branches_page_1.json through api/branches_page_5.json: exact API observations.
- original_census_source121.py: exact source of that completed census.
- verify_tree_streams121.py: portable metadata-only reproduction using the argument vector git, -C, REPO, ls-tree, -r, -z, COMMIT, with GIT_NO_LAZY_FETCH=1 and GIT_OPTIONAL_LOCKS=0.

The approximately 800 MB of compressed duplicate full-tree streams remain temporary audit transport. The repository carries their exact hashes and reproducible command rather than duplicating those streams in the author package. Reproducing them is a metadata verification, not a rerun of old science. The portable verifier is not represented as executed merely because its source is supplied.

## Theorems, proofs, model definitions and programs

The initial exact scaffold is provenance121/SCAFFOLD_RETENTION121.json: 402 copied content records bound to R120 V. The four old wrappers are separately preserved under provenance121/wrappers120/INDEX121.json. New active wrappers may reorganize the manuscript but do not rewrite those original wrappers or old evidence.

| Scientific content | Retained source route | Current treatment |
|---|---|---|
| Original Bellman sandwich, own-future constructive operator and actor/critic account | new110/core-main.tex and retained construction/proof inputs | Original source remains unchanged. new121/core_main121.tex makes the paid original-primitive continuation definition explicit without editing the old source. |
| Original constrained investment primitives and terminal cost | new110/continuous-main.tex, new/continuous95-tail99.tex and sections/proofs95.tex | The same state, risk law, capacity, transition, cost and implemented future controller define the current economic comparison. |
| Finite-horizon existence, measurable selectors, terminal stability, boundaries and computational-graph derivatives | new119/foundations_main.tex, new119/foundations_supplement.tex | Explicit assumptions remain; no convergence claim for an arbitrary joint actor/critic scalar loss. |
| Historical false composite-loss, viscosity-selection, Epstein–Zin/Merton, trace-objective and unsupported-extension claims | new119/original_correctness119.tex and exact original source/report routes | Corrected archival history stays visible. Original false statements are not silently edited or reinstated as active results. |
| Nonlinear recursive utility / BSDE bridge and boundaries | new110/recursive_bridge.tex, retained bridge inputs, new119/foundations_supplement.tex | The boundedness, comparison, generator, filtration and stopping assumptions remain separate from the investment application. |
| Action-null quotient and common-risk contrasts | R52/R99 inherited inputs; new119/coupled_main.tex, new119/coupled_proofs.tex | Earlier ownership is credited. An action-null state anchor cannot simply be discarded in a recursive Bellman composition. |
| Deterministic univariate uniform-law AVaR tail-uniform width | new119/active_tail_main.tex, new119/active_tail_proofs.tex | The achieved R119 order and exact scalar point-query assumptions remain; no formula-oracle lower bound for every economy is inferred. |
| Bounded tail prelude, exact packing and policy certificates | Retained new119 budgeted-tail, packing and policy inputs; code119 | Adverse A/B stages and the stronger C packed service remain distinct; the same returned policy is not an economic gain. |
| Independent Fraction validation | new119/independent_validation119_proof.tex, study/development D inputs and receipts | All 983 old keys retain their containment directions; fine shared-compiler endpoints are not independently certified by compatibility. |
| Paired certificate, tail transfer, positive-margin stopping and future-controller floor | new120/policy_improvement_main.tex, new120/policy_improvement_proofs.tex, code120 | Retain proofs, oracle qualifiers, inactivity findings and complete cost comparisons. |
| Independent all-action optimum supports and fixed-population inference | R120 proofs, independent/statistical programs and raw outputs | Original regret and action-distance bounds retain the once-only future allowance. Cross-arm exploratory contrasts are not added to the fixed population family. |
| New original-risk marginal acquisition and fitting | new121/marginal_main.tex, new121/marginal_proofs.tex, code121 | Actual source F is 16bf21334efcbc719b83e2ccf10e8527f8b956f2. Same paid bundle, features and box within each VALUE/MARGINAL pair. Integration of policy outcomes and their independent validation remains pending. |

The completed compact registry is provenance121/lineage121/theorem_code_registry_attempt02/THEOREM_PROOF_CODE_REGISTRY121.json.gz, with its actual successful EXECUTION121.json, scope README121.md and portable source build_theorem_code_registry121.py. It read and indexed all **252 retained TeX files and 179 Python files**, totaling **4,339,946 source bytes**, and records **113 statement environments, 95 proof environments, 66 proof-heading segments, 815 literal labels, 377 input edges and 1,918 Python definition records**. All four current wrapper inclusion closures have no unresolved literal input edge in this structural scan. TeX expansion and build verification remain separate.

All **69 historical route-bound TeX sources and 13 historical route-bound Python sources** are indexed. Ten small programs absent from the R120 scaffold were copied unchanged into provenance121/lineage121/archival_route_code121/ and verified against the original R119 tree, byte count, SHA-256 and Git blob. Its INDEX121.json binds 160,666 source bytes, nine actual GitHub blob responses and one already-local Git blob. The original 132 proof/action source objects remain intact: 103 exact direct-tree identities and 29 result archive-member bindings. The latter are retained through the immutable original maps and evidence; this structural census does not claim to reread or execute those raw result members.

The initial metadata attempt stopped because the same file identity had different optional label lists in different historical routes. Its failed receipt and exact generator source remain in theorem_code_registry_attempt01/. The corrected metadata generator preserves every original binding variant while grouping only identical file identities; no historical route, manuscript or scientific source was changed to fit the check. The second attempt completed successfully.

This registry records syntax and custody, not fresh proof-by-proof revalidation of the historical supplement and development companion. Explicit proof references and input links are indexed; an automatically identified preceding statement is only a structural candidate. A proof's presence, label link or current wrapper placement is not a theorem-validity verdict. Every program was parsed without importing or executing it. The snapshot is dated and bound to its observed source bytes; later source integration requires a new snapshot rather than overwriting this one.

The actual resumed verification is provenance121/lineage121/RESUMPTION_READBACK121.json. Its standard-library verifier, verify_retention121.py, rechecked all 35 original report bodies, all 30 exact quotations and complete inherited R120 records, the 303-commit compact census, independent-episode copies, ten additional historical programs, and the saved structural-registry outputs. It did not repeat semantic reading or scientific computation. Its explicit list of later editorial/reporting source changes prevents the dated structural snapshot from being presented as a final-source scan.

## Preserved positive and negative results

The revision preserves earlier genuine contributions: finite-menu protected comparisons with their adapted-control limitation, direct own-network Bellman residuals, executed original-primitives own-future neural training, full recursive sweeps at their own model and horizon, action-null quotients, and the bounded readout/dual proposal. Their original report and evidence routes remain available.

The adverse results also remain. R49's sharper internal certificate coexisted with original-policy losses. R97's certificate-oriented fits reduced an internal span while first-action rejections rose from 644 to 757. R119 A/B/C includes every conventional winner, cost reversal and unchanged-policy identity. R120 changed actions safely but did not establish a strict incremental paired-service mean win; it was slower than legacy-safe refinement in all 48 matched clocks, and direct refinement was faster than it in all 48.

R120's 4,096 primary decisions, 6,144 timing decisions, 861 independent policy keys, 111,069 terminal contexts, 4,096 comparisons and 55,104 all-action support rows remain source-bound R120 observations. The new mixed bound was necessary at two accepted records representing **one shared candidate**, not two discoveries. The transferred deficit was inactive in all 2,290 density pairs. All 512 ReLU–hinge policies agree, and all 14 learned completed means are worse than the online control. The 42 positive within-incumbent population lower bounds do not establish cross-arm population superiority.

The price statement retains its exact quantifier: 32 three-clock ReLU/full-menu upper-region intersections are empty, but 12 individual-clock upper regions and two actual-primary upper regions are nonempty and unresolved. No sufficient region is manufactured from an unresolved upper set.

## Independent, frozen or incompletely handed-over work

Exact original constraints and their read-back identities are in provenance121/independent_constraints121/. Newer boundary bodies and source identities are in provenance121/episode_boundaries121/. A frozen protocol remains binding even if a later experiment uses similar terminology.

| Episode | Immutable source / boundary | Required separation |
|---|---|---|
| R98 action-aligned acquisition | Head 54b1e58a5e7c84163fc64768ff18b5a1a4af3ef2; PROTOCOL98.md, REVISION_SCOPE98.md | Three rank-six families, own training/validation and selected-model barrier before its own 1,024 test states per risk. R121 data cannot complete it. |
| R111 paid-information policies | Head 7ac51c264f835598ad0ef1a58b7a747df0b2c5dd; original protocol and POST_EXECUTION_AUDIT111.md | Its document reports actual 9,600 primary and 21,504 timing decisions while specifying a later audit. That text is not an independently observed audit pass. |
| R112/R113 paid-support and roof constructions | Heads 0550bb4e1c529b27ed21548b965151d1af758e80, aceda95cb906431abd32fb0d4facb6dc290983af | Their grids, service catalogues, future-policy allowances and finite information classes remain fixed. Transport failure differs from scientific failure. |
| Remote R114/R115 population study | R114 8fbe018465bccae143109ba179270d5abff0e59d; R115 568fcf9358aa776a5ce846c748c370484b00cacd | Preserve actor commit ab43bbd84403ec715e29e2bae22fbeb9ded9c0aa, 8,192 entropy bytes, 1,024 states and the original 49,152-decision design. Dated evaluation_started:false is not a present process-status observation. |
| Different local oracle study also called R114 | Local commit ec7c1112281aea87034887f7eccd2feb879d62fb, freeze 0ebcd653a4c35d7faceb58ea730ceb2706babacc | It is not remote R114 or the R115 sample. A supplied insert is not a complete manuscript. |
| R116 regular-density risk computation | Head afb4093585c6dca8986e633e3ae1952ab15582a2 | Preserve fixed function/law/stream catalogue and formula-oracle distinction; no original-investment or population gain is inferred. |
| R117 geometric qualification | Head 15e6f291b3255dfac0865a9959222939d1c419da; freeze a21e33471047b966dd375d0b9aceab6b9492e4fb | Its pre-science HTTP 401 transport failure and later actual unchanged R119 reproduction are different observations. |
| R118 exact quadratic oracle | Head 01f17a992eb14053524ee2b0b63b083f022f8e82 | Article inherits R110; truncated transport is not a completed newer article. Its 792-cell mechanism, later reproduced by R119, is not the original investment model. |
| Completed R119 | Author S 6250abfd317f3b2a56cb1303eb5ce78249bf4042, V 82618f037540233dda7d1ba8bfd3ddfdc88afbf9 | A/B/C and D retain separate prospective freezes and costs. No phase is substituted for R120/R121. |
| Completed R120 | F 369d02724cf12ae0e54390b4e7b5f894f703892e; M 1c5e4dc7e04c108fe698d4c247a144b625db301c; D aebc7a0175c0729b9ff5e833a7facc1ed5c4c2fd; reporting 594d9336d89bedfd360e942146ae490e0fabd3a0 | Barriers, old failed metadata/auditor attempts, original science, exact inference family, complete source/PDF CI and final package remain unchanged. |

R119's actual unchanged R117 reproduction contains 4,608 primary and 7,168 timing decisions, preserved policy identities and five adverse clock cells. Its R118 reproduction contains 792 exact cells, 41,403 checks, 26,136 exhaustive action comparisons, 352 strict improvements and 440 ties. These achieved reproductions are retained, not called unfinished; they do not complete another episode's missing random experiment.

## Current execution and publication boundary

At initial map preparation, R121 acquisition, actual-model barrier, sample, primary decisions, timing, independent reconstruction, fit audit and reporting had not occurred. The source and protocols have since been published and read back at **F = 16bf21334efcbc719b83e2ccf10e8527f8b956f2**, root tree **06a225aa95dab260982fcbf972c80a7f6626bbfa**, native revision tree **2666e47a9b5376904bf53ad187b97a850107fc30**, before original-model acquisition. The 58-cell, 3,712-primary, 9,280-timing catalogue remains the frozen design; policy outcomes and their independent validation are still pending at this update. The source binding receipt is provenance121/lineage121/RESPONSE_FREEZE_BINDING121.json. Actual acquisition launch receipts record their own stages and costs; publication of F is not completion of M, D, primary evaluation, inference or adoption.

The separate complete-actor commit **M = 796c5f2badf68b051ac6c144884c0e61b87faf5e** and new-state commit **D = 68eae434c0e61fb1a61c3271c651c83c28619a07** have now actually been published. provenance121/M_PUBLICATION121.json binds all 56 actors, both independent training audits and 374 reconstructed native blobs before held-out entropy or outcomes existed. provenance121/D_PUBLICATION121.json binds the subsequent 640-byte draw and 64 exact state rows, with no outcome generated before D. These are custody and stage facts. The 30-item response update records them in provenance121/lineage121/RESPONSE_MD_BINDING121.json while retaining all economic outcome and closure fields pending. The assembly workflow recorded in M is not the final author-source publication CI.

Automated workspace maintenance removed the previous local Git metadata while retaining the native revision files. provenance121/LOCAL_GIT_RESTORATION121.json records restoration from shallow remote F and reconstruction of 179 exact F blobs without overwriting working sources or evidence. This local recovery does not invalidate the earlier dated 303-head census or make it a new current-remote observation. Rebuilding the final structural index requires the two original baseline commit trees; its planned command and prerequisites are recorded in provenance121/lineage121/FINAL_STRUCTURE_INDEX_PLAN121.md.

Actual R120 source CI run **39240515942** completed successfully and produced artifact **12181820272**. Its downloaded content and exact four-PDF comparison remain R120 evidence. Old failures, earlier queued observations and later successful source-bound runs retain their own times; the history is not rewritten as uniformly successful. R121 CI, source/PDF hashes and package verification will be claimed only from actual later receipts. Separate declaration files avoid embedding a future self-commit identity into the source it names.

