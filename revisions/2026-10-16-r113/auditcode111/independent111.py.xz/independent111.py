"""Independent rational verification of the frozen R111 publication records.

No import of bank111, fitting111 or runtime111. The lower-envelope minimizer
is recomputed on active-line intervals; upper bounds are recomputed by a
two-anchor linear-program enumeration rather than the production hull stack.
Timing replay identities are not counted as independent scientific samples.
"""
from __future__ import annotations
from pathlib import Path
from fractions import Fraction as Q
import argparse, collections, hashlib, json, math, time

TAU=Q(1,256); WIDTH=Q(1,8192); FUTURE=Q(15,2**24)
CONTROL={'completed':'completed','full':'full','budget':'budget','paired':'full','construct':'full','budget-construct':'budget'}
COUNTS=collections.Counter();CACHE={}

def enc(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def sha(x):return hashlib.sha256(enc(x)).hexdigest()
def F(x):
    if isinstance(x,float):assert math.isfinite(x)
    return Q(x)
def check(x,what):
    COUNTS[what]+=1
    if not x:raise AssertionError(what)
def out(q,upper):
    v=float(q)
    return math.nextafter(v,math.inf if upper else -math.inf) if ((F(v)<q) if upper else (F(v)>q)) else v

def curve(w,a,s,u):return w+s*(u-a)+(u-a)**2

def independent_core(state,records):
    key=sha([state,records])
    if key in CACHE:
        COUNTS['identical_geometric_inputs_reused']+=1
        return CACHE[key]
    cap=Q(1,8)+sum(map(F,state))/16
    check(len(state)==2 and all(0<=F(x)<=1 for x in state),'original_state_domain')
    curves=[];uppers={};lowers={};oldopt=[]
    for j,r in enumerate(records):
        a,w,smin,smax=map(lambda k:F(r[k]),('a','w','slo','shi'))
        check(0<=a<=cap and smin<=smax,'feasible_witness_anchor')
        midpoint=(smin+smax)/2;w -= (smax-smin)*max(a,cap-a)/2
        curves.append((w,a,midpoint,j))
        if 'q_upper' in r:
            qu,ju,jl=map(lambda k:F(r[k]),('q_upper','upper','lower'))
            check(jl<=qu<=ju,'paid_interval_order')
            if a not in uppers:uppers[a]=(qu,ju);lowers[a]=jl
            else:uppers[a]=(min(qu,uppers[a][0]),min(ju,uppers[a][1]));lowers[a]=max(jl,lowers[a])
            oldopt.append(F(r['optimum_lower']))
    check(bool(uppers),'at_least_one_paid_value')
    def lower(u):return max(curve(w,a,s,u) for w,a,s,_ in curves)
    # Differences of common-curvature quadratics are affine. Identify the
    # active quadratic on each complete intersection interval, independently
    # of the production enumeration of every curve's unconstrained vertex.
    cuts={Q(0),cap}
    for j,(w,a,s,_) in enumerate(curves):
        for z,b,t,_ in curves[:j]:
            slope=s-2*a-t+2*b
            if slope:
                cross=(curve(z,b,t,Q(0))-curve(w,a,s,Q(0)))/slope
                if 0<cross<cap:cuts.add(cross)
    cuts=sorted(cuts);critical=list(cuts)
    for l,r in zip(cuts,cuts[1:]):
        midpoint=(l+r)/2;w,a,s,_=max(curves,key=lambda c:curve(*c[:3],midpoint))
        critical.append(min(r,max(l,a-s/2)))
    modelmin=min(map(lower,critical));opt=max([modelmin]+oldopt)
    # A one-dimensional convex-combination LP needs at most two anchors.
    xs=sorted(uppers)
    def upper(u):
        check(xs[0]<=u<=xs[-1],'no_secant_extrapolation')
        values=[]
        if u in uppers:values.append(uppers[u][0])
        for j,a in enumerate(xs):
            for b in xs[j+1:]:
                if a<=u<=b:
                    lam=(b-u)/(b-a)
                    values.append(lam*uppers[a][0]+(1-lam)*uppers[b][0]-lam*(1-lam)*(b-a)**2)
        return min(values)
    for a,(qu,ju) in uppers.items():check(lower(a)<=qu and opt<=qu and lowers[a]<=ju,'consistent_original_objective_information')
    # Identify the affine pieces of U(u)-u^2 by pair enumeration on adjacent
    # input intervals. Merge equal affine pieces to obtain maximal segments.
    pieces=[]
    for l,r in zip(xs,xs[1:]):
        mid=(l+r)/2;options=[]
        for j,a in enumerate(xs):
            for b in xs[j+1:]:
                if a<=mid<=b:
                    va=uppers[a][0]-a*a;vb=uppers[b][0]-b*b
                    slope=(vb-va)/(b-a);intercept=va-slope*a
                    options.append((slope*mid+intercept,slope,intercept))
        _,s,c=min(options)
        if pieces and pieces[-1][2:]==(s,c):pieces[-1]=(pieces[-1][0],r,s,c)
        else:pieces.append((l,r,s,c))
    value=dict(cap=cap,curves=curves,lower=lower,upper=upper,uppers=uppers,lowers=lowers,
               opt=opt,modelmin=modelmin,pieces=pieces)
    CACHE[key]=value;COUNTS['unique_geometric_inputs']+=1
    return value

def audit_post(state,records,control,post,construct):
    c=independent_core(state,records);lower=c['lower'];upper=c['upper'];opt=c['opt']
    olda=F(control['a']);oldlo=max(F(control['lower']),lower(olda),opt)
    check(F(post['model_min'])==c['modelmin'],'independent_lower_envelope_minimum')
    check(F(post['optimum_lower'])==opt,'optimal_value_lower_bound')
    check(F(post['incumbent_sharpened_lower'])==oldlo,'incumbent_policy_lower_bound')
    check(F(post['future_policy_allowance'])==FUTURE,'full_future_policy_allowance')
    check(post['new_bellman_queries']==0,'zero_new_bellman_queries_recorded')
    expected=set(c['uppers'])
    if construct:
        for l,r,s,b in c['pieces']:
            lo=Q(-((-l.numerator*2**30)//l.denominator),2**30)
            hi=Q((r.numerator*2**30)//r.denominator,2**30)
            if lo>hi:continue
            v=min(r,max(l,-s/2));v=Q((v.numerator*2**30)//v.denominator,2**30)
            expected.add(min(hi,max(lo,v)))
    check(expected==set(F(r['a']) for r in post['candidates']),'complete_independent_candidate_set')
    eligible=[]
    for j,r in enumerate(post['candidates']):
        a=F(r['a']);lo=max(lower(a),opt);hi=upper(a)+FUTURE
        if a in c['uppers']:lo=max(lo,c['lowers'][a]);hi=min(hi,c['uppers'][a][1])
        check(lo==F(r['lower']) and hi==F(r['upper']),'independent_policy_envelope')
        check(F(r['published_lower'])<=lo<=hi<=F(r['published_upper']),'outward_policy_endpoints')
        check(r['published_lower']==out(lo,False) and r['published_upper']==out(hi,True),'minimal_outward_endpoint_conversion')
        check(F(r['optimum_lower'])<=opt,'outward_optimal_lower_bound')
        check(F(r['loss'])>=F(r['published_upper'])-F(r['optimum_lower']) and F(r['width'])>=F(r['published_upper'])-F(r['published_lower']),'outward_gap_and_width')
        qualifies=F(r['loss'])<=TAU and F(r['width'])<=WIDTH
        strict=qualifies and a!=olda and F(r['published_upper'])<oldlo
        check(r['qualifies']==qualifies and r['strictly_better']==strict,'exact_candidate_acceptance_gate')
        if strict:eligible.append((F(r['published_upper']),a,j))
    ans=post['answer']
    if eligible:
        high,a,j=min(eligible)
        check(ans['bank_accepted'] and ans['candidate_index']==j and F(ans['a'])==a,'best_qualified_strict_candidate_selected')
        check(ans['bank_new_action']==(a not in c['uppers']),'unqueried_action_identity')
        check(0<F(ans['certified_gain_lower'])<=oldlo-high,'positive_original_policy_improvement')
        COUNTS['accepted_new_actions' if ans['bank_new_action'] else 'accepted_queried_actions']+=1
    else:
        check(not ans['bank_accepted'] and not ans['bank_new_action'] and ans['certified_gain_lower']==0,'no_false_improvement')
        check(all(ans[k]==control[k] for k in ('a','lower','upper','optimum_lower','loss','width')),'unchanged_control_on_rejection')
    check(F(ans['a'])>=0 and F(ans['a'])<=c['cap'],'returned_action_feasible')

def audit_document(path,primary):
    data=json.loads(path.read_text());trace=data['trace'];mode=data['mode']
    check(sha(trace)==data['trace_sha256'],'complete_control_trace_digest')
    check(trace['control']==CONTROL[mode],'prespecified_control_mapping')
    check(data['post_primitive_counts']=={},'no_additional_primitive_counter_events')
    check(data['rss_is_process_high_water_not_incremental'],'memory_scope_correct')
    for t in trace['trials']:
        if t['omitted']:
            check(F(t['stop_gap'])<=Q(1,2**16) and CONTROL[mode]=='budget','valid_gain_budget_omission')
        elif t['accepted']:
            check(t['candidate_a']!=t['incumbent_a'] and F(t['candidate_upper'])<F(t['incumbent_lower']),'strict_control_trial_descent')
            check(F(t['candidate_upper'])-F(t['candidate_optimum_lower'])<=TAU and F(t['candidate_upper'])-F(t['candidate_lower'])<=WIDTH,'control_trial_original_qualification')
        COUNTS['primary_trial_slots' if primary else 'timing_trial_slots']+=1
    for row,records,post in zip(trace['rows'],trace['banks'],data['post']):
        ans=post['answer'];cap=Q(1,8)+sum(map(F,row['x']))/16
        check(0<=F(ans['a'])<=cap,'original_action_feasibility')
        check(F(ans['lower'])<=F(ans['upper']) and F(ans['optimum_lower'])<=F(ans['upper']),'returned_interval_consistent')
        check(0<=F(ans['loss'])<=TAU and 0<=F(ans['width'])<=WIDTH,'unchanged_original_tolerances')
        check(F(ans['loss'])>=F(ans['upper'])-F(ans['optimum_lower']) and F(ans['width'])>=F(ans['upper'])-F(ans['lower']),'returned_gap_width_enclose')
        check(F(ans['action_distance_upper'])**2>=F(ans['loss']),'outward_curvature_action_distance')
        if mode in ('paired','construct','budget-construct'):audit_post(row['x'],records,row,post,mode!='paired')
        else:check(not ans['bank_accepted'] and all(ans[k]==row[k] for k in ('a','lower','upper','optimum_lower','loss','width')),'control_answer_identity')
        COUNTS['primary_decisions' if primary else 'timing_decisions']+=1
    return data

def piecewise_avar(segments,alpha):
    """Exact AVaR for affine pieces on a uniform interval; inverse-CDF algorithm.

    segments=(left,right,slope,intercept), covering an interval without overlap.
    Atoms are handled explicitly; no formula for the test mechanism is used.
    """
    segments=[tuple(map(F,s)) for s in segments];alpha=F(alpha)
    length=sum(r-l for l,r,s,b in segments)
    def cdf(y):
        total=Q(0)
        for l,r,s,b in segments:
            if s==0:total+=(r-l) if b<=y else 0
            elif s>0:total+=max(Q(0),min(r,(y-b)/s)-l)
            else:total+=max(Q(0),r-max(l,(y-b)/s))
        return total/length
    knots=sorted({s*x+b for l,r,s,b in segments for x in (l,r)})
    eta=knots[0]
    if cdf(eta)<alpha:
        for lo,hi in zip(knots,knots[1:]):
            if cdf(hi)>=alpha:
                # Continuous affine-piece fixtures have no atoms. For an atom
                # at hi, left-limit mass determines whether quantile is hi.
                atom=sum(r-l for l,r,s,b in segments if s==0 and b==hi)/length
                before=cdf(hi)-atom
                eta=hi if before<=alpha else lo+(hi-lo)*(alpha-cdf(lo))/(before-cdf(lo))
                break
    surplus=Q(0)
    for l,r,s,b in segments:
        if s==0:surplus+=(r-l)*max(Q(0),b-eta)
        elif s>0:
            v=max(l,min(r,(eta-b)/s));surplus+=s*(r*r-v*v)/2+(b-eta)*(r-v)
        else:
            v=max(l,min(r,(eta-b)/s));surplus+=s*(v*v-l*l)/2+(b-eta)*(v-l)
    return eta+surplus/(length*(1-alpha))

def mechanism_checks():
    rows=[]
    for k in range(1,13):
        e=Q(1,2**k);g=[(-1,1,1,0)];f=[(-1,0,1,e),(0,1,1,-e)]
        rg=piecewise_avar(g,Q(1,2));rf=piecewise_avar(f,Q(1,2));d=-e
        # Independent explicit polynomial integration over original-law tails.
        def integral(s,b,l,r):return s*(r*r-l*l)/2+b*(r-l)
        direct=integral(1,e,-e,0)+integral(1,-e,e,1)
        check(rf==direct and rg==Q(1,2),'independent_continuous_tail_integration')
        check(rf-rg-d==e*e,'second_order_paired_tail_remainder')
        # Band |z|<=2e, local contrast span 2e, t=1/2.
        bound=2*e*min(2*e,Q(1))
        check(0<=rf-rg-d<=bound,'centered_tail_margin_bound')
        rows.append(dict(epsilon=str(e),risk_f=str(rf),risk_g=str(rg),common_witness_contrast=str(d),remainder=str(e*e),tail_bound=str(bound)))
    return rows

def run(root,out):
    started=time.perf_counter();record=json.loads((root/'EXECUTION111.json').read_text())
    check(record['status']=='executed' and all(p['exit_code']==0 for p in record['processes']),'actual_primary_and_timing_exit_codes')
    check(record['source']['source_commit']=='0512e86b83280391c4084040e5d3cf52738c867c','actual_pre_execution_source_freeze')
    hashes={};files=[];accepted=[]
    for primary,folder in ((True,'catalogue'),(False,'timing')):
        for p in sorted((root/folder).glob('*.json')):
            if p.name.startswith('PROCESS-'):continue
            d=audit_document(p,primary);mode=d['mode']
            if primary:
                group=(d['index'],d['arm'],CONTROL[mode]);h=d['trace_sha256']
                if group in hashes:check(hashes[group]==h,'paired_services_identical_completed_control')
                hashes[group]=h
                for row,post in zip(d['trace']['rows'],d['post']):
                    if post['answer']['bank_accepted']:accepted.append(dict(file=p.name,row=row['row'],x=row['x'],control=row,post=post))
            files.append(dict(path=str(p.relative_to(root)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    check(COUNTS['primary_decisions']==9600,'complete_primary_catalogue')
    check(COUNTS['timing_decisions']==21504,'complete_seven_process_timing_catalogue')
    mech=mechanism_checks()
    data=dict(status='passed',scope='Independent scalar rational envelope, gate, feasibility and trace verification; original numerical witness validity additionally relies on the retained primitive theorems and separately reported risk replay.',
              source_commit=record['source']['source_commit'],audit_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),counts=dict(COUNTS),seconds=time.perf_counter()-started,
              primary_accepted_actions=len(accepted),accepted=accepted,mechanisms=mech,verified_files=files,
              duplicate_timing_replays_are_not_independent_samples=True)
    with out.open('x') as f:json.dump(data,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps({k:data[k] for k in ('status','primary_accepted_actions','seconds','counts')},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args();run(a.root,a.output)
